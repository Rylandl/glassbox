from __future__ import annotations

import numpy as np

from glassbox.belief.belief import DynamicsBelief
from glassbox.belief.belief_io import save_dynamics_belief
from glassbox.core.data import Trajectory, save_trajectory_npz
from glassbox.core.fixedwing_synthetic import true_fixed_wing_parameters
from glassbox.core.model import ExecutableModel, runtime_spec_from_trajectory
from glassbox.io.corpus import REFERENCE_CORPORA
from glassbox.io.x8_reference import (
    X8ReferenceAdapter,
    x8_trajectory_spec,
)
from glassbox.workflows.evaluate import evaluate


def _write_fixture(path) -> np.ndarray:
    data = np.zeros((4, 41), dtype=np.float64)
    data[:, 0] = np.arange(4) * 0.025
    data[:, 1] = (0.10, 0.11, 0.12, 0.13)
    data[:, 2] = (-0.20, -0.19, -0.18, -0.17)
    data[:, 3] = (0.40, 0.41, 0.42, 0.43)
    data[:, 13:16] = (0.1, 0.2, 0.3)
    data[:, 16:19] = (10.0, 2.0, -1.0)
    data[:, 19:22] = (10.0, 2.0, -1.0)
    data[:, 22:25] = (4.0, -3.0, -0.5)
    data[:, 32] = np.arange(4) * 0.25
    data[:, 33] = np.arange(4) * 0.05
    data[:, 34] = np.arange(4) * -0.025
    np.savetxt(path, data, delimiter=",")
    return data


def test_x8_adapter_emits_typed_flying_wing_trajectory(tmp_path) -> None:
    source = tmp_path / "lateral_121_1.csv"
    data = _write_fixture(source)

    trajectory = X8ReferenceAdapter(verify_checksum=False).load(source)

    assert trajectory.spec == x8_trajectory_spec()
    assert trajectory.spec.vehicle.fixed_states["airframe_layout"] == "flying_wing"
    assert trajectory.spec.control_roles == ("throttle", "roll", "pitch")
    assert trajectory.spec.control_names == ("throttle", "aileron", "elevator")
    np.testing.assert_allclose(trajectory.controls[0], data[0, (3, 2, 1)])
    np.testing.assert_allclose(trajectory.states[0, 3:6], (10.0, -2.0, 1.0))
    np.testing.assert_allclose(trajectory.states[0, 6:10], (1.0, 0.0, 0.0, 0.0))
    np.testing.assert_allclose(trajectory.states[0, 10:13], (0.1, -0.2, -0.3))
    np.testing.assert_allclose(trajectory.states[1, 0:3], (0.25, -0.05, 0.025))
    assert trajectory.labels["benchmark_split"] == "training"
    assert trajectory.labels["profile"] == "lateral_121"
    assert trajectory.labels["replicate"] == 1
    assert trajectory.exogenous_size == 3
    assert trajectory.spec.exogenous_roles == (
        "wind_north",
        "wind_west",
        "wind_up",
    )
    np.testing.assert_allclose(trajectory.exogenous[0], (4.0, 3.0, 0.5))
    assert "exogenous" in trajectory.provenance


def test_x8_inspection_audits_source_consistency(tmp_path) -> None:
    source = tmp_path / "lateral_121_1.csv"
    _write_fixture(source)

    inventory = X8ReferenceAdapter(verify_checksum=False).inspect(source)

    assert inventory["intervals"] == 3
    assert np.isclose(inventory["duration_s"], 0.075)
    assert inventory["quality"]["sample_rate_hz"] == 40.0
    assert inventory["quality"]["maximum_body_velocity_consistency_error_m_s"] < 1e-12
    assert inventory["checksum_matches_pinned_snapshot"] is False


def test_x8_adapter_can_exclude_the_wind_estimate_for_ablation(tmp_path) -> None:
    source = tmp_path / "lateral_121_1.csv"
    _write_fixture(source)

    trajectory = X8ReferenceAdapter(
        verify_checksum=False,
        use_trusted_wind_estimate=False,
    ).load(source)

    assert trajectory.spec.exogenous_roles == ()
    assert trajectory.exogenous_size == 0
    assert trajectory.provenance["excluded_exogenous"]["prediction_policy"] == (
        "not_supplied_to_model"
    )


def test_x8_evaluation_requires_and_scores_upstream_validation(tmp_path) -> None:
    source = tmp_path / "lateral_121_1.csv"
    _write_fixture(source)
    trajectory = X8ReferenceAdapter(verify_checksum=False).load(source)
    trajectory = Trajectory(
        time_s=trajectory.time_s,
        states=trajectory.states,
        controls=trajectory.controls,
        exogenous=trajectory.exogenous,
        spec=trajectory.spec,
        labels={**trajectory.labels, "benchmark_split": "validation"},
        provenance=trajectory.provenance,
    )
    trajectory_path = tmp_path / "validation.npz"
    model_path = tmp_path / "model.json"
    save_trajectory_npz(trajectory, trajectory_path)
    save_dynamics_belief(
        DynamicsBelief(
            model=ExecutableModel(
                true_fixed_wing_parameters(),
                x8_trajectory_spec(),
                runtime_spec_from_trajectory(trajectory),
            ),
        ),
        model_path,
    )

    paths, trajectories = REFERENCE_CORPORA["x8"].load_evaluation_trajectories(
        [trajectory_path]
    )
    report = evaluate(
        model_path,
        trajectories,
        protocol="x8",
        horizons_s=(0.025,),
    )

    assert paths == [trajectory_path.resolve()]
    assert report["protocol"] == "x8"
    assert report["baseline"] == "kinematic_persistence"
    assert report["stride"] == "one_sample"
    assert report["floors"] == dict.fromkeys(report["floors"], 1e-12)
    assert report["independent_holdout"] is True
    assert report["dataset"]["trajectory_count"] == 1
    assert "0.025s" in report["model"]["horizon_rollouts"]
    assert np.isfinite(report["score_vs_baseline"])
