"""Reduce archived paired errors with equal weight per fitted replicate."""
import hashlib,json,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path.cwd()/'scripts'))
import evaluate_fit_uncertainty as study
from glassbox.core.dynamics import structured_parameter_vector
from glassbox.core.synthetic import true_parameters

ROOT=Path('/tmp/glassbox-state-reconstruction')
OLD=Path('/tmp/glassbox-noisy-fit-investigation/confirmation')
GROUPS=study.TANGENT_GROUP_INDICES
TRUTH=np.asarray(structured_parameter_vector(true_parameters()))
INDICES=[0,2,3,4,5,6,7,8,9]


def mse(errors):
    # replicate, initialization, window, horizon, tangent coordinate
    return {group:np.mean(errors[...,indices]**2,axis=(0,2,4)).tolist()
            for group,indices in GROUPS.items()}


def summary(data,model):
    results={}
    for scope in ('cold','history_available','all'):
        cases=[]
        for item in data:
            cold=item[f'0/{model}/observed_error']
            warm=item[f'25/{model}/observed_error']
            cases.append(cold if scope=='cold' else warm if scope=='history_available' else np.concatenate((cold,warm),axis=1))
        results[scope]={'windows_per_fit':cases[0].shape[1],'observed_mse':mse(np.stack(cases))}
    results['maximum_stationarity']=float(max(np.max(d[f'25/{model}/stationarity']) for d in data))
    return results


report={'design':dict(
    purpose='test a shared local least-squares state solve before changing fitting or forecasting defaults',
    sample_period_s=.02,past_steps=25,horizons_s=study.HORIZONS,
    initializer='four Gauss-Newton iterations in 12 scaled rigid-body coordinates; six backtracking trials per iteration',
    weights='training-only rollout error scales; equal semantic groups; uniform observation time weights during causal reconstruction',
    measurement_noise_std=study.NOISE_STD.tolist(),
    forecast='past observations through the forecast origin only; future controls are supplied; observed future states are used only for scoring',
    command_history='50 commands before the reconstruction window, then the window controls; identical resulting actuator state for raw and reconstructed starts',
    scoring='endpoint mean squared tangent error per state group, all windows, no support filtering',
    cold_start='first forecast of every test flight has one observation and uses it unchanged',
    source_study='initial-state-fitting/evidence.zip; models and paired data seeds unchanged',
    comparison_replicates=list(range(16,20)),
    training_seeds='100000+10*replicate+i; observation noise 200000+10*replicate+i; i=0,1',
    test_seeds='500000+i; observation noise 600000+10*replicate+i; i=0,1,2',
    conditions=study.CONDITIONS,
    uncertainty='four fitted replicates per synthetic condition; profile-fitter probe has one replicate per condition',
    production_change=False), 'paired_forecasts':{},'profile_fitting':{}}
for condition in study.CONDITIONS:
    data=[dict(np.load(ROOT/'paired'/f'{condition}-{rep}.npz')) for rep in range(16,20)]
    report['paired_forecasts'][condition]={name:summary(data,name) for name in ('fixed_4000','joint_4000')}
    # Show both component changes together against the same raw-start baseline.
    for scope in ('cold','history_available','all'):
        base=report['paired_forecasts'][condition]['fixed_4000'][scope]['observed_mse']
        new=report['paired_forecasts'][condition]['joint_4000'][scope]['observed_mse']
        ratios={g:(np.asarray(new[g])[1]/np.maximum(np.asarray(base[g])[0],1e-30)).tolist() for g in GROUPS}
        report['paired_forecasts'][condition].setdefault('joint_history_over_fixed_raw',{})[scope]=ratios
    # Probe of local elimination in the fitting objective.
    source=ROOT/'profile'/f'{condition}-16'
    params=dict(np.load(source/'models.npz'))
    old=dict(np.load(OLD/condition/'16'/'arrays.npz'))
    param_errors={name:float(np.mean((vector[INDICES]-TRUTH[INDICES])**2)) for name,vector in params.items()}
    param_errors.update({name:float(np.mean((old[f'{name}/theta'][INDICES]-TRUTH[INDICES])**2)) for name in ('fixed_400','joint_400','fixed_4000','joint_4000')})
    forecasts=[dict(np.load(ROOT/'paired'/f'profile-{condition}-16.npz'))]
    report['profile_fitting'][condition]=dict(parameter_mse=param_errors,forecasts={name:summary(forecasts,name) for name in params},optimization=json.loads((source/'report.json').read_text()))
report['profile_fitting']['design']={
    'optimizer':'400 Adam steps, learning rate .02; parameter masks and clipping unchanged',
    'objective':'initial observation plus all forecast observations in scaled 12-coordinate local geometry; initial weight one, future weights linearly one to three',
    'comparator':'fixed_geometry holds the start fixed in the exact same objective; fixed_400 and joint_400 are prior-study production and joint-offset fits',
    'temporary_states':'recomputed by four local Gauss-Newton iterations per objective evaluation; stopped-gradient state corrections in the parameter gradient',
    'scope':'single synthetic replicate per condition; unpenalized observation objective; soft support penalty monitored at reported steps but omitted from this probe',
    'gradient_check':{'windows':2,'parameter_point':'initial_parameter_guess','relative_error_against_full_differentiation':{'1_iteration':.000603996857535094,'4_iterations':1.537354705760663e-06,'8_iterations':1.537354705760663e-06}},
}
arp=[dict(np.load(ROOT/'paired'/'arp.npz'))]
report['arp']={'model':'current history-corrected artifact, unchanged coefficients','training_flights':[63,64,65],'test_flight':66,'result':summary(arp,'current')}
report['generality']=json.loads((ROOT/'generality.json').read_text())
report['decision']='retain the shared local state-solve prototype for identification; do not add unconditional history reconstruction or change production defaults on this evidence'
paths=[*sorted(ROOT.glob('*.py')),*sorted(Path('src/glassbox').rglob('*.py')),Path('scripts/evaluate_fit_uncertainty.py'),Path('artifacts/arp_reference/model.json'),*sorted(Path('artifacts/arp_reference/canonical').glob('*.npz'))]
report['source_sha256']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
(ROOT/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
for condition in study.CONDITIONS:
    ratios=report['paired_forecasts'][condition]['joint_history_over_fixed_raw']
    print(condition,'warm ratios at 1s',[ratios['history_available'][g][-1] for g in GROUPS], 'all',[ratios['all'][g][-1] for g in GROUPS])
    print('profile parameter mse',report['profile_fitting'][condition]['parameter_mse'])
