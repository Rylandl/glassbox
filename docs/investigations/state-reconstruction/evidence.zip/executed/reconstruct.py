"""Local state reconstruction using the existing rigid-body rollout."""
from __future__ import annotations
import jax
import jax.numpy as jnp
from glassbox.core.dynamics import rollout_with_latent
from glassbox.core.geometry import rigid_body_local_error, state_plus_tangent


def reconstruct(params, observed, controls, dt_s, initial_latent, scales,
                control_roles=None, exogenous=None, exogenous_roles=None):
    def predict(offset):
        return rollout_with_latent(params, state_plus_tangent(observed[0], offset*scales),
            controls, dt_s, initial_latent, control_roles, exogenous, exogenous_roles)
    def residual(offset):
        predicted,_=predict(offset)
        return (jax.vmap(rigid_body_local_error)(predicted,observed)/scales).ravel()
    def iteration(offset,unused):
        r=residual(offset)
        jac=jax.jacfwd(residual)(offset)
        gram=jac.T@jac
        diagonal=jnp.sqrt(jnp.maximum(jnp.diag(gram),1e-12))
        normalized=gram/diagonal[:,None]/diagonal[None,:]
        delta=jnp.linalg.solve(normalized+8*jnp.finfo(gram.dtype).eps*jnp.eye(12),
                              (jac.T@r)/diagonal)/diagonal
        current=r@r
        def trial(carry,fraction):
            best,accepted=carry
            candidate=offset-fraction*delta
            error=residual(candidate)
            accept=(~accepted)&jnp.isfinite(error@error)&(error@error<current)
            return (jnp.where(accept,candidate,best),accepted|accept),None
        (next_offset,_),_=jax.lax.scan(trial,(offset,jnp.asarray(False)),.5**jnp.arange(6))
        return next_offset,None
    offset,_=jax.lax.scan(iteration,jnp.zeros(12,dtype=observed.dtype),None,length=4)
    states,latent=predict(offset)
    r=residual(offset)
    stationarity=jnp.max(jnp.abs(jax.jacfwd(residual)(offset).T@r))/len(r)
    return states,latent,stationarity
