"""Read-only PX4 MAVLink telemetry integration for shadow-mode evaluation."""

from __future__ import annotations

import time
from collections import deque
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from threading import Condition, Event, Thread
from typing import Any, Protocol, TypeVar

import numpy as np

from glassbox.integrations.loop import Observation
from glassbox.io.px4_frames import (
    frd_to_flu,
    ned_frd_quaternion_to_nwu_flu,
    ned_to_nwu,
)

PX4_STATE_MESSAGE_TYPES = ("LOCAL_POSITION_NED", "ATTITUDE_QUATERNION")
PX4_HIL_ACTUATOR_MESSAGE_TYPES = ("HIL_ACTUATOR_CONTROLS",)
_BOOT_TIME_MODULUS_MS = 2**32
_RECEIVE_POLL_TIMEOUT_S = 0.10
_MAXIMUM_DRAIN_MESSAGES = 4096
_MAV_MODE_FLAG_SAFETY_ARMED = 128
_HIL_ACTUATOR_HISTORY_SIZE = 512
_MAXIMUM_APPLIED_COMMAND_STATE_SKEW_S = 0.10

Item = TypeVar("Item")


class PX4TelemetryError(RuntimeError):
    """Raised when PX4 cannot provide a fresh canonical state sample."""


class _MAVLinkMessage(Protocol):
    time_boot_ms: int

    def get_type(self) -> str: ...

    def get_srcSystem(self) -> int: ...


class _MAVLinkConnection(Protocol):
    # Keyword names intentionally mirror pymavlink's public call surface.
    def wait_heartbeat(self, *, timeout: float) -> object | None: ...

    def recv_match(
        self,
        *,
        type: list[str],
        blocking: bool,
        timeout: float,
    ) -> _MAVLinkMessage | None: ...

    def close(self) -> None: ...


@dataclass(frozen=True)
class PX4StateSample:
    """One timestamp-audited canonical rigid-body state from PX4."""

    state: np.ndarray
    position_time_boot_ms: int
    attitude_time_boot_ms: int
    message_skew_s: float
    maximum_receive_age_s: float
    estimated_source_clock_lag_s: float = 0.0
    received_at_s: float | None = None

    def __post_init__(self) -> None:
        state = np.asarray(self.state, dtype=np.float64)
        if state.shape != (13,) or not np.all(np.isfinite(state)):
            raise ValueError("PX4 canonical state must contain 13 finite values")
        if not np.isclose(np.linalg.norm(state[6:10]), 1.0, atol=1e-9):
            raise ValueError("PX4 canonical attitude must be a unit quaternion")
        if not 0 <= self.position_time_boot_ms < _BOOT_TIME_MODULUS_MS:
            raise ValueError("PX4 position boot timestamp is outside uint32 range")
        if not 0 <= self.attitude_time_boot_ms < _BOOT_TIME_MODULUS_MS:
            raise ValueError("PX4 attitude boot timestamp is outside uint32 range")
        timing = np.asarray(
            [
                self.message_skew_s,
                self.maximum_receive_age_s,
                self.estimated_source_clock_lag_s,
            ]
        )
        if not np.all(np.isfinite(timing)) or np.any(timing < 0.0):
            raise ValueError(
                "PX4 state timing diagnostics must be finite and nonnegative"
            )
        object.__setattr__(self, "state", state)
        if self.received_at_s is not None and not np.isfinite(self.received_at_s):
            raise ValueError("PX4 reception timestamp must be finite")


@dataclass(frozen=True)
class PX4AppliedCommandSample:
    """One canonical applied-command sample from a PX4 HIL telemetry link."""

    command: np.ndarray
    source_time_us: int
    mav_mode: int
    armed: bool
    receive_age_s: float

    def __post_init__(self) -> None:
        command = np.asarray(self.command, dtype=np.float64)
        if command.ndim != 1 or command.size < 1 or not np.all(np.isfinite(command)):
            raise ValueError("PX4 applied command must be a nonempty finite vector")
        if self.source_time_us < 0:
            raise ValueError("PX4 applied-command source timestamp must be nonnegative")
        if not 0 <= self.mav_mode <= 255:
            raise ValueError("PX4 applied-command MAV mode is outside uint8 range")
        if bool(self.armed) != bool(self.mav_mode & _MAV_MODE_FLAG_SAFETY_ARMED):
            raise ValueError("PX4 applied-command armed state disagrees with MAV mode")
        if not np.isfinite(self.receive_age_s) or self.receive_age_s < 0.0:
            raise ValueError("PX4 applied-command receive age must be nonnegative")
        object.__setattr__(self, "command", command)


@dataclass(frozen=True)
class _ReceivedMessage:
    message: _MAVLinkMessage
    received_monotonic_s: float
    generation: int


@dataclass(frozen=True)
class _ReceivedAppliedCommand:
    command: np.ndarray
    source_time_us: int
    mav_mode: int
    received_monotonic_s: float


def _px4_boot_time_difference_ms(first_ms: int, second_ms: int) -> int:
    return (
        int(first_ms) - int(second_ms) + _BOOT_TIME_MODULUS_MS // 2
    ) % _BOOT_TIME_MODULUS_MS - _BOOT_TIME_MODULUS_MS // 2


def px4_boot_time_skew_s(first_ms: int, second_ms: int) -> float:
    """Return the absolute distance between wrapping PX4 boot timestamps."""

    return abs(_px4_boot_time_difference_ms(first_ms, second_ms)) * 1e-3


def _connect_px4(
    connection_string: str,
    heartbeat_timeout_s: float,
) -> tuple[_MAVLinkConnection, int]:
    """Open a passive MAVLink listener and verify one PX4 heartbeat."""

    if not np.isfinite(heartbeat_timeout_s) or heartbeat_timeout_s <= 0:
        raise ValueError("heartbeat_timeout_s must be finite and positive")
    from pymavlink import mavutil

    connection = mavutil.mavlink_connection(connection_string)
    heartbeat = connection.wait_heartbeat(timeout=float(heartbeat_timeout_s))
    if heartbeat is None:
        connection.close()
        raise PX4TelemetryError(f"no PX4 heartbeat received from {connection_string!r}")
    if int(getattr(heartbeat, "autopilot", -1)) != int(
        mavutil.mavlink.MAV_AUTOPILOT_PX4
    ):
        connection.close()
        raise PX4TelemetryError(
            f"heartbeat from {connection_string!r} is not a PX4 autopilot"
        )
    return connection, int(heartbeat.get_srcSystem())


class _LatchedReceiver:
    """One passive MAVLink receive thread with a latched decode history.

    Both PX4 sources in this module are the same machine: a daemon thread blocks
    on one message-type set, drains whatever else the transport has already
    buffered, decodes each message through a source-specific decoder, and
    publishes the results under a condition variable so a reader can wait for
    something fresh. Retaining only what has been latched is required even in
    shadow mode, because a solver can block long enough for a receive buffer to
    preserve old datagrams while dropping newer ones.

    What differs between the two sources is the decoder and the rule a reader
    selects the history by, so those are the two things this receiver takes.
    ``source_time_of`` is the third: when a source carries a vehicle clock, a
    backwards step in it means PX4 restarted, and everything latched from the
    previous boot is dropped rather than left to compete for selection.
    """

    def __init__(
        self,
        connection: _MAVLinkConnection,
        message_types: Sequence[str],
        decode: Callable[[_MAVLinkMessage], Any | None],
        *,
        label: str,
        thread_name: str,
        source_system: int | None = None,
        history_size: int = 1,
        source_time_of: Callable[[Any], int] | None = None,
    ) -> None:
        self._connection = connection
        self._message_types = list(message_types)
        self._decode = decode
        self._label = label
        self._source_system = source_system
        self._source_time_of = source_time_of
        self._condition = Condition()
        self._stop_requested = Event()
        self.history: deque[Any] = deque(maxlen=history_size)
        self.latest_sequence = 0
        self.delivered_sequence = 0
        self._receiver_error: Exception | None = None
        self._closed = False
        self._receiver = Thread(
            target=self._receive_forever,
            name=thread_name,
            daemon=True,
        )
        self._receiver.start()

    def _decoded(self, message: _MAVLinkMessage) -> Any | None:
        if (
            self._source_system is not None
            and int(message.get_srcSystem()) != self._source_system
        ):
            return None
        return self._decode(message)

    def _receive_batch(self) -> list[Any]:
        """Block for one message, then drain the transport, decoding as we go."""

        decoded: list[Any] = []
        message = self._connection.recv_match(
            type=self._message_types,
            blocking=True,
            timeout=_RECEIVE_POLL_TIMEOUT_S,
        )
        if message is None:
            return decoded
        for _ in range(_MAXIMUM_DRAIN_MESSAGES):
            item = self._decoded(message)
            if item is not None:
                decoded.append(item)
            message = self._connection.recv_match(
                type=self._message_types,
                blocking=False,
                timeout=0.0,
            )
            if message is None:
                break
        return decoded

    def _drop_previous_boot(self, items: list[Any]) -> list[Any]:
        source_time_of = self._source_time_of
        if source_time_of is None:
            return items
        previous = source_time_of(self.history[-1]) if self.history else None
        reset_index: int | None = None
        for index, item in enumerate(items):
            current = source_time_of(item)
            if previous is not None and current < previous:
                reset_index = index
            previous = current
        if reset_index is None:
            return items
        # PX4 restarted; samples from the previous boot must never compete in
        # nearest-timestamp selection.
        self.history.clear()
        return items[reset_index:]

    def _receive_forever(self) -> None:
        try:
            while not self._stop_requested.is_set():
                items = self._receive_batch()
                if not items:
                    continue
                with self._condition:
                    retained = self._drop_previous_boot(items)
                    self.history.extend(retained)
                    self.latest_sequence += len(retained)
                    self._condition.notify_all()
        except Exception as error:
            with self._condition:
                if not self._closed:
                    self._receiver_error = error
                    self._condition.notify_all()

    def take_fresh(self) -> Any | None:
        """Return the newest latched item once, or ``None`` until one arrives."""

        if self.latest_sequence <= self.delivered_sequence:
            return None
        self.delivered_sequence = self.latest_sequence
        return self.history[-1]

    def wait(
        self,
        select: Callable[[], Item | None],
        *,
        timeout_s: float,
        timeout_message: str,
    ) -> Item:
        """Wait until ``select`` accepts the latched history, or time out."""

        if not np.isfinite(timeout_s) or timeout_s <= 0:
            raise ValueError("timeout_s must be finite and positive")
        deadline = time.monotonic() + timeout_s
        with self._condition:
            while True:
                if self._receiver_error is not None:
                    raise PX4TelemetryError(
                        f"{self._label} receiver failed"
                    ) from self._receiver_error
                if self._closed:
                    raise PX4TelemetryError(f"{self._label} source is closed")
                selected = select()
                if selected is not None:
                    return selected
                remaining_s = deadline - time.monotonic()
                if remaining_s <= 0.0:
                    raise PX4TelemetryError(timeout_message)
                self._condition.wait(timeout=remaining_s)

    def close(self) -> None:
        with self._condition:
            if self._closed:
                return
            self._closed = True
            self._stop_requested.set()
            self._condition.notify_all()
        self._connection.close()
        self._receiver.join(timeout=1.0)


class PX4StateAssembler:
    """Pair asynchronous PX4 state messages into fresh canonical samples."""

    def __init__(
        self,
        *,
        maximum_message_skew_s: float = 0.10,
        maximum_receive_age_s: float = 0.25,
    ) -> None:
        if not np.isfinite(maximum_message_skew_s) or maximum_message_skew_s <= 0:
            raise ValueError("maximum_message_skew_s must be finite and positive")
        if not np.isfinite(maximum_receive_age_s) or maximum_receive_age_s <= 0:
            raise ValueError("maximum_receive_age_s must be finite and positive")
        self.maximum_message_skew_s = float(maximum_message_skew_s)
        self.maximum_receive_age_s = float(maximum_receive_age_s)
        self._position: _ReceivedMessage | None = None
        self._attitude: _ReceivedMessage | None = None
        self._generation = 0
        self._emitted_generations = (-1, -1)
        self._previous_quaternion: np.ndarray | None = None
        self._last_position_boot_ms: int | None = None
        self._unwrapped_position_boot_ms = 0
        self._minimum_clock_offset_s: float | None = None

    def _source_clock_lag_s(self, boot_ms: int, received_at_s: float) -> float:
        previous_boot_ms = self._last_position_boot_ms
        if previous_boot_ms is None:
            self._unwrapped_position_boot_ms = boot_ms
            self._minimum_clock_offset_s = None
        else:
            advance_ms = (
                boot_ms - previous_boot_ms + _BOOT_TIME_MODULUS_MS // 2
            ) % _BOOT_TIME_MODULUS_MS - _BOOT_TIME_MODULUS_MS // 2
            if advance_ms < 0:
                # A negative source-time jump indicates a PX4 restart. Re-anchor
                # rather than treating the new boot as years of transport lag.
                self._unwrapped_position_boot_ms = boot_ms
                self._minimum_clock_offset_s = None
            else:
                self._unwrapped_position_boot_ms += advance_ms
        self._last_position_boot_ms = boot_ms

        clock_offset_s = received_at_s - self._unwrapped_position_boot_ms * 1e-3
        if (
            self._minimum_clock_offset_s is None
            or clock_offset_s < self._minimum_clock_offset_s
        ):
            self._minimum_clock_offset_s = clock_offset_s
        return max(0.0, clock_offset_s - self._minimum_clock_offset_s)

    def ingest(
        self,
        message: _MAVLinkMessage,
        *,
        received_monotonic_s: float | None = None,
    ) -> PX4StateSample | None:
        """Consume one message and return a state once both streams advance."""

        message_type = message.get_type()
        if message_type not in PX4_STATE_MESSAGE_TYPES:
            return None
        received_at = (
            time.monotonic()
            if received_monotonic_s is None
            else float(received_monotonic_s)
        )
        if not np.isfinite(received_at):
            raise ValueError("received_monotonic_s must be finite")
        self._generation += 1
        received = _ReceivedMessage(message, received_at, self._generation)
        if message_type == "LOCAL_POSITION_NED":
            self._position = received
        else:
            self._attitude = received
        return self._assemble(received_at)

    def _assemble(self, now_s: float) -> PX4StateSample | None:
        position = self._position
        attitude = self._attitude
        if position is None or attitude is None:
            return None
        generations = (position.generation, attitude.generation)
        if any(
            current <= emitted
            for current, emitted in zip(generations, self._emitted_generations)
        ):
            return None

        ages = np.asarray(
            [
                now_s - position.received_monotonic_s,
                now_s - attitude.received_monotonic_s,
            ]
        )
        if np.any(ages < 0.0) or np.max(ages) > self.maximum_receive_age_s:
            return None

        position_boot_ms = int(position.message.time_boot_ms)
        attitude_boot_ms = int(attitude.message.time_boot_ms)
        skew_s = px4_boot_time_skew_s(position_boot_ms, attitude_boot_ms)
        if skew_s > self.maximum_message_skew_s:
            return None

        world_position = ned_to_nwu(
            [position.message.x, position.message.y, position.message.z]
        )
        world_velocity = ned_to_nwu(
            [position.message.vx, position.message.vy, position.message.vz]
        )
        quaternion = ned_frd_quaternion_to_nwu_flu(
            [
                attitude.message.q1,
                attitude.message.q2,
                attitude.message.q3,
                attitude.message.q4,
            ]
        )
        quaternion_norm = np.linalg.norm(quaternion)
        if not np.isfinite(quaternion_norm) or quaternion_norm < 1e-6:
            raise PX4TelemetryError("PX4 supplied an invalid attitude quaternion")
        quaternion = quaternion / quaternion_norm
        if (
            self._previous_quaternion is not None
            and np.dot(self._previous_quaternion, quaternion) < 0.0
        ):
            quaternion = -quaternion
        body_rates = frd_to_flu(
            [
                attitude.message.rollspeed,
                attitude.message.pitchspeed,
                attitude.message.yawspeed,
            ]
        )
        state = np.concatenate((world_position, world_velocity, quaternion, body_rates))
        if not np.all(np.isfinite(state)):
            raise PX4TelemetryError("PX4 supplied a non-finite state")

        self._previous_quaternion = quaternion
        self._emitted_generations = generations
        return PX4StateSample(
            state=state,
            position_time_boot_ms=position_boot_ms,
            attitude_time_boot_ms=attitude_boot_ms,
            message_skew_s=skew_s,
            maximum_receive_age_s=float(np.max(ages)),
            estimated_source_clock_lag_s=self._source_clock_lag_s(
                position_boot_ms, now_s
            ),
            received_at_s=min(
                position.received_monotonic_s, attitude.received_monotonic_s
            ),
        )


class PX4MavlinkStateSource:
    """Receive PX4 state estimates without transmitting MAVLink messages."""

    def __init__(
        self,
        connection: _MAVLinkConnection,
        *,
        assembler: PX4StateAssembler | None = None,
        source_system: int | None = None,
    ) -> None:
        self._assembler = PX4StateAssembler() if assembler is None else assembler
        self._receiver = _LatchedReceiver(
            connection,
            PX4_STATE_MESSAGE_TYPES,
            self._assembler.ingest,
            label="PX4 telemetry",
            thread_name="glassbox-px4-telemetry",
            source_system=source_system,
        )

    @classmethod
    def connect(
        cls,
        connection_string: str = "udpin:0.0.0.0:14550",
        *,
        heartbeat_timeout_s: float = 10.0,
        assembler: PX4StateAssembler | None = None,
    ) -> PX4MavlinkStateSource:
        """Open a passive MAVLink listener and wait for a PX4 heartbeat."""

        connection, source_system = _connect_px4(connection_string, heartbeat_timeout_s)
        return cls(connection, assembler=assembler, source_system=source_system)

    def next_sample(self, *, timeout_s: float = 1.0) -> PX4StateSample:
        """Wait for the next fresh, time-aligned canonical state sample."""

        return self._receiver.wait(
            self._receiver.take_fresh,
            timeout_s=timeout_s,
            timeout_message=(
                "timed out waiting for fresh LOCAL_POSITION_NED and "
                "ATTITUDE_QUATERNION messages"
            ),
        )

    def close(self) -> None:
        self._receiver.close()

    def __enter__(self) -> PX4MavlinkStateSource:
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()


class PX4HILActuatorSource:
    """Passively receive canonical applied commands from PX4 HIL telemetry.

    ``HIL_ACTUATOR_CONTROLS`` uses PX4 actuator-output order, which is vehicle
    configuration dependent. Callers must provide indices that map that order
    into the fitted artifact's canonical command order. This source is intended
    for simulator integration tests; it never transmits MAVLink messages.
    """

    def __init__(
        self,
        connection: _MAVLinkConnection,
        *,
        command_indices: tuple[int, ...],
        source_system: int | None = None,
        maximum_receive_age_s: float = 0.25,
    ) -> None:
        if (
            not command_indices
            or len(set(command_indices)) != len(command_indices)
            or min(command_indices) < 0
        ):
            raise ValueError(
                "command_indices must contain distinct nonnegative indices"
            )
        if not np.isfinite(maximum_receive_age_s) or maximum_receive_age_s <= 0:
            raise ValueError("maximum_receive_age_s must be finite and positive")
        self._command_indices = command_indices
        self._maximum_receive_age_s = float(maximum_receive_age_s)
        self._receiver = _LatchedReceiver(
            connection,
            PX4_HIL_ACTUATOR_MESSAGE_TYPES,
            self._decode,
            label="PX4 HIL actuator",
            thread_name="glassbox-px4-hil-actuators",
            source_system=source_system,
            history_size=_HIL_ACTUATOR_HISTORY_SIZE,
            source_time_of=lambda item: item.source_time_us,
        )

    @classmethod
    def connect(
        cls,
        connection_string: str = "udpin:0.0.0.0:19410",
        *,
        command_indices: tuple[int, ...],
        heartbeat_timeout_s: float = 10.0,
        maximum_receive_age_s: float = 0.25,
    ) -> PX4HILActuatorSource:
        """Open a passive PX4 HIL actuator listener and verify its heartbeat."""

        connection, source_system = _connect_px4(connection_string, heartbeat_timeout_s)
        return cls(
            connection,
            command_indices=command_indices,
            source_system=source_system,
            maximum_receive_age_s=maximum_receive_age_s,
        )

    def _decode(self, message: _MAVLinkMessage) -> _ReceivedAppliedCommand:
        controls = np.asarray(message.controls, dtype=np.float64)
        highest_index = max(self._command_indices)
        if controls.ndim != 1 or controls.size <= highest_index:
            raise PX4TelemetryError(
                "PX4 HIL actuator vector does not contain configured indices"
            )
        command = controls[list(self._command_indices)]
        if not np.all(np.isfinite(command)):
            raise PX4TelemetryError("PX4 supplied a non-finite HIL actuator command")
        source_time_us = int(message.time_usec)
        mav_mode = int(message.mode)
        if source_time_us < 0 or not 0 <= mav_mode <= 255:
            raise PX4TelemetryError("PX4 supplied invalid HIL actuator metadata")
        return _ReceivedAppliedCommand(
            command=command,
            source_time_us=source_time_us,
            mav_mode=mav_mode,
            received_monotonic_s=time.monotonic(),
        )

    def _sample(
        self, received: _ReceivedAppliedCommand
    ) -> PX4AppliedCommandSample | None:
        receive_age_s = time.monotonic() - received.received_monotonic_s
        if receive_age_s > self._maximum_receive_age_s:
            return None
        return PX4AppliedCommandSample(
            command=received.command,
            source_time_us=received.source_time_us,
            mav_mode=received.mav_mode,
            armed=bool(received.mav_mode & _MAV_MODE_FLAG_SAFETY_ARMED),
            receive_age_s=receive_age_s,
        )

    def _fresh_sample(self) -> PX4AppliedCommandSample | None:
        received = self._receiver.take_fresh()
        return None if received is None else self._sample(received)

    def _nearest_sample(self, time_boot_ms: int) -> PX4AppliedCommandSample | None:
        history = self._receiver.history
        if not history:
            return None
        latest_boot_ms = (history[-1].source_time_us // 1_000) % _BOOT_TIME_MODULUS_MS
        if _px4_boot_time_difference_ms(latest_boot_ms, time_boot_ms) < 0:
            return None
        nearest = min(
            history,
            key=lambda item: px4_boot_time_skew_s(
                (item.source_time_us // 1_000) % _BOOT_TIME_MODULUS_MS,
                time_boot_ms,
            ),
        )
        return self._sample(nearest)

    def next_sample(self, *, timeout_s: float = 1.0) -> PX4AppliedCommandSample:
        """Wait for the next fresh canonical applied-command sample."""

        return self._receiver.wait(
            self._fresh_sample,
            timeout_s=timeout_s,
            timeout_message="timed out waiting for fresh HIL_ACTUATOR_CONTROLS",
        )

    def sample_nearest(
        self,
        time_boot_ms: int,
        *,
        timeout_s: float = 1.0,
    ) -> PX4AppliedCommandSample:
        """Return the retained actuator sample nearest one PX4 boot time."""

        if not 0 <= time_boot_ms < _BOOT_TIME_MODULUS_MS:
            raise ValueError("PX4 target boot timestamp is outside uint32 range")
        return self._receiver.wait(
            lambda: self._nearest_sample(time_boot_ms),
            timeout_s=timeout_s,
            timeout_message=(
                "timed out waiting for HIL actuator telemetry at PX4 "
                f"boot time {time_boot_ms} ms"
            ),
        )

    def close(self) -> None:
        self._receiver.close()

    def __enter__(self) -> PX4HILActuatorSource:
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()


class PX4MavlinkLink:
    """A read-only vehicle link over passive PX4 MAVLink telemetry.

    Shadow mode is the product feature this link exists for: it reads canonical
    state paired with the command PX4 actually applied, and refuses to write.
    The applied command is either a constant the operator declares or the
    vehicle's own actuator telemetry; when it comes from telemetry, a state and
    a command further apart than the alignment limit are refused rather than
    paired, because a solve against a mismatched pair measures nothing.
    """

    writable = False

    def __init__(
        self,
        state_source: PX4MavlinkStateSource,
        *,
        command_size: int,
        command_bounds: tuple[Any, Any],
        applied_command_source: Any | None = None,
        fixed_command: Any | None = None,
        maximum_applied_command_state_skew_s: float = (
            _MAXIMUM_APPLIED_COMMAND_STATE_SKEW_S
        ),
    ) -> None:
        if command_size < 1:
            raise ValueError("command_size must be positive")
        minimum, maximum = (
            np.asarray(bound, dtype=np.float64) for bound in command_bounds
        )
        if minimum.shape != (command_size,) or maximum.shape != (command_size,):
            raise ValueError(f"command bounds must each contain {command_size} values")
        if applied_command_source is None and fixed_command is None:
            raise ValueError(
                "provide either a fixed applied command or an applied_command_source"
            )
        if applied_command_source is not None and fixed_command is not None:
            raise ValueError(
                "fixed_command and applied_command_source are mutually exclusive"
            )
        skew_limit = float(maximum_applied_command_state_skew_s)
        if not np.isfinite(skew_limit) or skew_limit <= 0.0:
            raise ValueError(
                "maximum_applied_command_state_skew_s must be finite and positive"
            )
        self.command_size = int(command_size)
        self.command_bounds = (minimum, maximum)
        self._state_source = state_source
        self._applied_command_source = applied_command_source
        self._maximum_applied_command_state_skew_s = skew_limit
        self._fixed_command = (
            None if fixed_command is None else self._bounded(fixed_command)
        )

    @property
    def applied_command_source_kind(self) -> str:
        """Where each interval's applied command comes from."""

        return "fixed" if self._applied_command_source is None else "telemetry"

    def _bounded(self, command: Any) -> np.ndarray:
        command = np.asarray(command, dtype=np.float64)
        expected_shape = (self.command_size,)
        if command.shape != expected_shape or not np.all(np.isfinite(command)):
            raise ValueError(
                f"applied command must have shape {expected_shape} and be finite"
            )
        minimum, maximum = self.command_bounds
        if np.any(command < minimum) or np.any(command > maximum):
            raise ValueError("applied command must lie inside the artifact bounds")
        return command

    def read(self, *, timeout_s: float) -> Observation:
        """Return one canonical state paired with the command PX4 applied."""

        sample = self._state_source.next_sample(timeout_s=timeout_s)
        # Preserve the oldest state component's reception time through both
        # receiver buffering and the wait for matching actuator telemetry.
        received_at_s = (
            time.monotonic() - sample.maximum_receive_age_s
            if sample.received_at_s is None
            else sample.received_at_s
        )
        if self._applied_command_source is None:
            if self._fixed_command is None:  # pragma: no cover - guarded above
                raise RuntimeError("fixed applied command was not initialized")
            command = self._fixed_command
            skew_s: float | None = None
            armed: bool | None = None
        else:
            applied = self._applied_command_source.sample_nearest(
                sample.position_time_boot_ms,
                timeout_s=timeout_s,
            )
            command = self._bounded(applied.command)
            skew_s = px4_boot_time_skew_s(
                sample.position_time_boot_ms,
                (applied.source_time_us // 1_000) % _BOOT_TIME_MODULUS_MS,
            )
            limit = self._maximum_applied_command_state_skew_s
            if skew_s > limit + 1e-12:
                raise PX4TelemetryError(
                    "PX4 state and applied-command telemetry exceed the "
                    f"{limit * 1_000:g} ms alignment limit"
                )
            armed = applied.armed
        return Observation(
            state=sample.state,
            applied_command=command,
            received_at_s=received_at_s,
            source_time_s=sample.position_time_boot_ms * 1e-3,
            message_skew_s=sample.message_skew_s,
            receive_age_s=max(0.0, time.monotonic() - received_at_s),
            source_clock_lag_s=sample.estimated_source_clock_lag_s,
            applied_command_skew_s=skew_s,
            armed=armed,
        )

    def write(self, command: Any) -> None:
        """Refuse every command: this link exists to never transmit one."""

        raise PX4TelemetryError(
            "the PX4 MAVLink link is read-only and never transmits commands"
        )
