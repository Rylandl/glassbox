"""Independently check every reported MSE against the evidence archive."""
import io,json,hashlib,zipfile
from pathlib import Path
import numpy as np
root=Path('docs/investigations/state-reconstruction')
report=json.loads((root/'report.json').read_text())
groups={'position':range(3),'velocity':range(3,6),'attitude':range(6,9),'angular_velocity':range(9,12)}
count=0
with zipfile.ZipFile(root/'evidence.zip') as z:
    assert z.testzip() is None
    assert json.loads(z.read('report.json'))==report
    def arrays(path):return dict(np.load(io.BytesIO(z.read(path)),allow_pickle=False))
    def check(data,models,rows):
        global count
        for model in models:
            for scope,past in (('cold',0),('history_available',25),('all',None)):
                values=[]
                for case in data:
                    a=case[f'0/{model}/observed_error']
                    b=case[f'25/{model}/observed_error']
                    values.append(a if past==0 else b if past==25 else np.concatenate((a,b),axis=1))
                a=np.asarray(values,dtype=np.float64)
                assert a.shape[2]==rows[model][scope]['windows_per_fit']
                assert np.all(np.isfinite(a))
                for group,idx in groups.items():
                    expected=np.mean(a[...,list(idx)]**2,axis=(0,2,4))
                    np.testing.assert_allclose(rows[model][scope]['observed_mse'][group],expected,rtol=2e-6,atol=1e-18)
                    count+=1
            for case in data:
                np.testing.assert_array_equal(case[f'0/{model}/observed_error'][0],case[f'0/{model}/observed_error'][1])
    for condition in ('clean','noisy','noisier','collective'):
        data=[arrays(f'paired/{condition}-{rep}.npz') for rep in range(16,20)]
        rows=report['paired_forecasts'][condition]
        check(data,('fixed_4000','joint_4000'),rows)
        for scope in ('cold','history_available','all'):
            original=[]
            for rep in range(16,20):
                a=arrays(f'previous/{condition}/{rep}/arrays.npz')['fixed_4000/observed_error'].reshape(3,6,3,12)
                original.append(a[:,0] if scope=='cold' else a[:,1:].reshape(15,3,12) if scope=='history_available' else a.reshape(18,3,12))
            a=np.asarray(original,dtype=np.float64)
            for group,idx in groups.items():
                expected=np.mean(a[...,list(idx)]**2,axis=(0,1,3))
                np.testing.assert_allclose(rows['production_raw_mse'][scope][group],expected,rtol=2e-6,atol=1e-18)
                ratio=np.asarray(rows['joint_4000'][scope]['observed_mse'][group])[1]/expected
                np.testing.assert_allclose(rows['joint_history_over_production_raw'][scope][group],ratio,rtol=2e-6,atol=1e-12)
                count+=2
        data=[arrays(f'paired/profile-{condition}-16.npz')]
        check(data,('profile','fixed_geometry'),report['profile_fitting'][condition]['forecasts'])
    check([arrays('paired/arp.npz')],('current',),{'current':report['arp']['result']})
    for path,sha in report['source_sha256'].items():
        if path.startswith('src/'):
            assert hashlib.sha256(z.read(path)).hexdigest()==sha
            assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==sha
    for path,sha in report['executed_source_sha256'].items():
        assert hashlib.sha256(z.read(path)).hexdigest()==sha
print(f'Verified {count} metric/ratio arrays, cold-start equality, source hashes and archive integrity.')
