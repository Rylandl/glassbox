# State reconstruction probes

The report records seeds, objectives, scoring and source hashes.

Run the archived Python sources from the repository root with its virtual
environment and `PYTHONPATH=src`. The executed scripts use
`/tmp/glassbox-state-reconstruction` for output and load the preceding study
from `/tmp/glassbox-noisy-fit-investigation/confirmation`. Restore `previous/`
to that location and the archived ARP inputs to `artifacts/arp_reference/`.
`paired.py` runs the synthetic comparison; `paired.py arp` runs the real-log
check. `profile.py CONDITION` runs a fitting probe; add `check` for the
gradient comparison. `generality.py` exercises the other model schemas.
`parity.py` compares the extracted common solve against `executed/`.
`candidate/summarize.py` reduces the arrays into the report.
