"""Eliminate local state corrections before a parameter update."""

import json, sys, time
from pathlib import Path
import jax
import jax.numpy as jnp
import numpy as np
from jax.flatten_util import ravel_pytree

sys.path.insert(0, str(Path.cwd() / "scripts"))
import evaluate_fit_uncertainty as study
from glassbox.core.data import trajectory_windows
from glassbox.core.dynamics import (
    control_state_after_history,
    rollout_with_latent,
    structured_parameter_vector,
    zero_angular_cross_coupling_gradient,
    zero_thrust_command_offset_gradient,
)
from glassbox.core.geometry import rigid_body_local_error, state_plus_tangent
from glassbox.core.identification import (
    rollout_loss_configuration,
    _fit_objective,
    dynamic_envelope_penalty,
)
from glassbox.core.synthetic import initial_parameter_guess, true_parameters
from paired import evaluate, scales_for


from reconstruct import solve_initial_correction


def make_objective(
    w, config, scales, *, profile=True, differentiate=False, iterations=4
):
    time_weights = jnp.concatenate(
        (jnp.ones(1), jnp.linspace(1.0, config.endpoint_weight, w.controls.shape[1]))
    )

    def one(params, observed, controls, history):
        latent = control_state_after_history(params, history, w.dt_s, w.control_roles)

        def prediction(offset):
            return rollout_with_latent(
                params,
                state_plus_tangent(observed[0], offset * scales),
                controls,
                w.dt_s,
                latent,
                w.control_roles,
            )[0]

        def residual(offset):
            states = prediction(offset)
            error = jax.vmap(rigid_body_local_error)(states, observed) / scales
            # sqrt of the existing soft support penalty; excluded initial sample.
            stability = dynamic_envelope_penalty(states[None, 1:], config)[0]
            # In these probes the trajectories remain inside the envelope. Avoid
            # sqrt(0) derivatives: keep that check explicit below.
            return (
                error * jnp.sqrt(time_weights[:, None] / jnp.sum(time_weights) / 12)
            ).ravel()

        offset = (
            solve_initial_correction(residual, jnp.zeros(12), iterations=iterations)
            if profile
            else jnp.zeros(12)
        )
        if not differentiate:
            offset = jax.lax.stop_gradient(offset)
        r = residual(offset)
        stationarity = jnp.max(jnp.abs(jax.jacfwd(residual)(offset).T @ r))
        stability = jnp.max(
            dynamic_envelope_penalty(prediction(offset)[None, 1:], config)
        )
        return r @ r, stationarity, stability

    def objective(params):
        values, grad, stability = jax.vmap(one, in_axes=(None, 0, 0, 0))(
            params,
            jnp.asarray(w.target_states),
            jnp.asarray(w.controls),
            jnp.asarray(w.control_histories),
        )
        return jnp.mean(values), jnp.stack((jnp.max(grad), jnp.max(stability)))

    return objective


def run(condition="noisy", rep=16, check=False):
    clean = [
        study.truth_flight(100000 + 10 * rep + i, condition == "collective")
        for i in range(2)
    ]
    measured = [
        study.noisy_trajectory(
            t, 200000 + 10 * rep + i, study.CONDITIONS[condition], "train"
        )
        for i, t in enumerate(clean)
    ]
    w = trajectory_windows(measured, horizon=25)
    config = rollout_loss_configuration([w])
    scales = scales_for(measured)
    initial = initial_parameter_guess()
    if check:
        from dataclasses import replace

        w = replace(
            w,
            initial_states=w.initial_states[:2],
            controls=w.controls[:2],
            target_states=w.target_states[:2],
            control_histories=w.control_histories[:2],
            initial_exogenous=w.initial_exogenous[:2],
        )
        theta, unravel = ravel_pytree(initial)
        for iterations in (1, 4, 8):
            gradients = []
            for differentiate in (False, True):
                objective = make_objective(
                    w,
                    config,
                    scales,
                    differentiate=differentiate,
                    iterations=iterations,
                )
                f = jax.jit(
                    jax.value_and_grad(
                        lambda theta: objective(unravel(theta)), has_aux=True
                    )
                )
                (value, diagnostic), grad = f(theta)
                gradients.append(np.asarray(grad))
                print(
                    "gradient",
                    iterations,
                    differentiate,
                    float(value),
                    np.asarray(diagnostic).tolist(),
                    flush=True,
                )
            print(
                "relative gradient discrepancy",
                float(
                    np.linalg.norm(gradients[0] - gradients[1])
                    / np.linalg.norm(gradients[1])
                ),
                flush=True,
            )
        return
    output = Path("/tmp/glassbox-state-reconstruction/profile") / f"{condition}-{rep}"
    output.mkdir(parents=True, exist_ok=True)
    models = {}
    report = {}
    for policy in ("profile", "fixed_geometry"):
        objective = make_objective(w, config, scales, profile=policy == "profile")
        normalizer = objective(initial)[0]
        value_and_grad = jax.value_and_grad(
            lambda p: (objective(p)[0] / normalizer, objective(p)[1]), has_aux=True
        )

        @jax.jit
        def step(params, first, second, index):
            (value, aux), gradient = value_and_grad(params)
            gradient = zero_angular_cross_coupling_gradient(
                zero_thrust_command_offset_gradient(gradient)
            )
            norm = jnp.sqrt(sum(jnp.sum(a * a) for a in jax.tree.leaves(gradient)))
            gradient = jax.tree.map(
                lambda a: a * jnp.minimum(1.0, 10.0 / (norm + 1e-12)), gradient
            )
            first = jax.tree.map(lambda a, g: 0.9 * a + 0.1 * g, first, gradient)
            second = jax.tree.map(
                lambda a, g: 0.999 * a + 0.001 * g * g, second, gradient
            )
            params = jax.tree.map(
                lambda p, a, b: (
                    p
                    - 0.02
                    * (a / (1 - 0.9**index))
                    / (jnp.sqrt(b / (1 - 0.999**index)) + 1e-8)
                ),
                params,
                first,
                second,
            )
            return params, first, second, value, aux

        params = initial
        first = jax.tree.map(jnp.zeros_like, params)
        second = first
        start = time.monotonic()
        diagnostics = []
        for index in range(1, 401):
            params, first, second, value, aux = step(params, first, second, index)
            if index % 100 == 0:
                diagnostics.append(
                    dict(
                        step=index,
                        loss=float(value),
                        diagnostic=np.asarray(aux).tolist(),
                        seconds=time.monotonic() - start,
                    )
                )
                print(condition, rep, policy, diagnostics[-1], flush=True)
        models[policy] = params
        report[policy] = diagnostics
    np.savez_compressed(
        output / "models.npz",
        **{
            name: np.asarray(structured_parameter_vector(p))
            for name, p in models.items()
        },
    )
    (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    true = [study.truth_flight(500000 + i, condition == "collective") for i in range(3)]
    observed = [
        study.noisy_trajectory(
            t, 600000 + 10 * rep + i, study.CONDITIONS[condition], "test"
        )
        for i, t in enumerate(true)
    ]
    evaluate(models, measured, observed, true, f"profile-{condition}-{rep}")


if __name__ == "__main__":
    run(sys.argv[1] if len(sys.argv) > 1 else "noisy", check="check" in sys.argv)
