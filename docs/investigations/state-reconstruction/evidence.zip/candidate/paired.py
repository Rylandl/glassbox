"""Paired causal-initialization comparison; all scoring is after forecast origin."""
import sys,json
from pathlib import Path
import jax
import jax.numpy as jnp
import numpy as np
sys.path.insert(0,str(Path.cwd()/'scripts'))
import evaluate_fit_uncertainty as study
from reconstruct import reconstruct
from glassbox.core.data import control_history_before,trajectory_windows,load_trajectory_npz
from glassbox.core.dynamics import control_state_after_history,rollout_with_latent,with_structured_parameter_vector
from glassbox.core.geometry import rigid_body_local_error
from glassbox.core.identification import rollout_loss_configuration
from glassbox.core.synthetic import true_parameters
from glassbox.core.model import ExecutableModel

ROOT=Path('/tmp/glassbox-state-reconstruction/paired')
ROOT.mkdir(exist_ok=True)
GROUPS=list(study.TANGENT_GROUP_INDICES.values())

def scales_for(training):
    config=rollout_loss_configuration([trajectory_windows(training,horizon=25)])
    return jnp.asarray(np.concatenate((config.position_scale_m,config.velocity_scale_m_s,
        np.repeat(config.attitude_scale_rad/np.sqrt(3),3),config.angular_velocity_scale_rad_s)))

def evaluate(models,training,observed,truth,output):
    scales=scales_for(training)
    roles=training[0].spec.control_roles
    exo_roles=training[0].spec.exogenous_roles
    dt=float(np.median(np.diff(training[0].time_s)))
    arrays={}
    # Empty history is an explicit cold start, never padded with later states.
    for past_steps,starts in ((0,(0,)),(25,range(50,min(len(t.controls) for t in observed)-49,50))):
        rows=[(t,a,s) for t,a in zip(observed,truth) for s in starts]
        hist=jnp.asarray(np.stack([control_history_before(t,s-past_steps,50) for t,a,s in rows]))
        states=jnp.asarray(np.stack([t.states[s-past_steps:s+1] for t,a,s in rows]))
        past=jnp.asarray(np.stack([t.controls[s-past_steps:s] for t,a,s in rows]))
        future=jnp.asarray(np.stack([t.controls[s:s+50] for t,a,s in rows]))
        context=jnp.asarray(np.stack([t.exogenous[s-past_steps:s+50] for t,a,s in rows]))
        actual=jnp.asarray(np.stack([a.states[s:s+51] for t,a,s in rows]))
        target=jnp.asarray(np.stack([t.states[s:s+51] for t,a,s in rows]))
        @jax.jit
        def batch(params):
            def one(obs,past,prefix,future,context):
                initial=control_state_after_history(params,prefix,dt,roles)
                if past_steps:
                    trace,latent,stationarity=reconstruct(params,obs,past,dt,initial,scales,
                        roles,context[:past_steps],exo_roles)
                else:
                    trace,latent,stationarity=obs,initial[None],jnp.asarray(0.)
                raw_latent=control_state_after_history(params,jnp.concatenate((prefix,past)),dt,roles)
                raw,_=rollout_with_latent(params,obs[-1],future,dt,raw_latent,roles,context[past_steps:],exo_roles)
                estimated,_=rollout_with_latent(params,trace[-1],future,dt,latent[-1],roles,context[past_steps:],exo_roles)
                return jnp.stack((raw,estimated)),stationarity
            return jax.vmap(one)(states,past,hist,future,context)
        for name,params in models.items():
            predicted,gradient=batch(params)
            errors=jax.vmap(jax.vmap(jax.vmap(rigid_body_local_error)),in_axes=(0,None))(predicted.transpose(1,0,2,3),target)
            latent_errors=jax.vmap(jax.vmap(jax.vmap(rigid_body_local_error)),in_axes=(0,None))(predicted.transpose(1,0,2,3),actual)
            arrays[f'{past_steps}/{name}/observed_error']=np.asarray(errors[:,:,jnp.asarray((5,25,50)),:])
            arrays[f'{past_steps}/{name}/latent_error']=np.asarray(latent_errors[:,:,jnp.asarray((5,25,50)),:])
            arrays[f'{past_steps}/{name}/stationarity']=np.asarray(gradient)
            mse=np.stack([np.mean(np.asarray(errors[:,:,50,idx])**2,axis=(1,2)) for idx in GROUPS],axis=1)
            print(output,past_steps,name,'MSE',mse.tolist(),'ratio',(mse[1]/np.maximum(mse[0],1e-30)).tolist(),flush=True)
    np.savez_compressed(ROOT/f'{output}.npz',**arrays)

if __name__=='__main__':
    if 'arp' in sys.argv:
        m=ExecutableModel.load('artifacts/arp_reference/model.json')
        paths=sorted(Path('artifacts/arp_reference/canonical').glob('*.npz'))
        train=[load_trajectory_npz(p) for p in paths[:3]]
        test=[load_trajectory_npz(paths[3])]
        evaluate({'current':m.params},train,test,test,'arp')
    else:
        for condition in study.CONDITIONS:
            for rep in range(16,20):
                clean=[study.truth_flight(100000+10*rep+i,condition=='collective') for i in range(2)]
                train=[study.noisy_trajectory(t,200000+10*rep+i,study.CONDITIONS[condition],'train') for i,t in enumerate(clean)]
                saved=np.load(Path('/tmp/glassbox-noisy-fit-investigation/confirmation')/condition/str(rep)/'arrays.npz')
                models={name:with_structured_parameter_vector(true_parameters(),jnp.asarray(saved[f'{name}/theta']))
                        for name in ('fixed_4000','joint_4000')}
                true=[study.truth_flight(500000+i,condition=='collective') for i in range(3)]
                measured=[study.noisy_trajectory(t,600000+10*rep+i,study.CONDITIONS[condition],'test') for i,t in enumerate(true)]
                evaluate(models,train,measured,true,f'{condition}-{rep}')
                jax.clear_caches()
