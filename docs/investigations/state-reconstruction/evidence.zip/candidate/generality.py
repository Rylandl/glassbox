"""Exercise the same reconstruction kernel across existing dynamics schemas."""
import json
from pathlib import Path
import jax
import jax.numpy as jnp
import numpy as np
from reconstruct import reconstruct
from glassbox.core.dynamics import rollout_with_latent,hover_control,fixed_wing_trim_control,initial_residual_parameters
from glassbox.core.fixedwing_synthetic import true_fixed_wing_parameters,fixed_wing_trim_state
from glassbox.core.synthetic import true_parameters
from glassbox.core.geometry import state_plus_tangent,rigid_body_local_error

root=Path('/tmp/glassbox-state-reconstruction')
results={}
scales=jnp.repeat(jnp.asarray((.05,.1,.03,.1)),3)
for family in ('quad','fixedwing','flyingwing_residual'):
    if family=='quad':
        params=true_parameters();roles=None
        state=jnp.asarray([0.,0,0,0,0,0,1,0,0,0,0,0,0]);latent=hover_control(params)
    else:
        params=true_fixed_wing_parameters()
        roles=('throttle','roll','pitch') if family=='flyingwing_residual' else ('throttle','roll','pitch','yaw')
        state=jnp.asarray(fixed_wing_trim_state());latent=fixed_wing_trim_control(params,15,roles)
        if family=='flyingwing_residual':
            params=initial_residual_parameters(params,control_size=3,exogenous_size=2)
            params=params._replace(output_weights=.03*jnp.ones_like(params.output_weights))
    controls=jnp.repeat(latent[None],25,axis=0)+.01*jnp.sin(jnp.arange(25)[:,None]*.12+jnp.arange(len(latent))[None])
    context=jnp.stack((.1*jnp.sin(jnp.arange(25)*.1),.1*jnp.cos(jnp.arange(25)*.1)),axis=1)
    exo_roles=('wind_north','wind_west')
    truth,true_latent=rollout_with_latent(params,state,controls,.02,latent,roles,context,exo_roles)
    noise=jnp.asarray(np.random.default_rng(714).normal(size=(26,12)))*jnp.repeat(jnp.asarray((.002,.02,.002,.01)),3)
    observed=jax.vmap(state_plus_tangent)(truth,noise)
    run=jax.jit(lambda obs:reconstruct(params,obs,controls,.02,latent,scales,roles,context,exo_roles))
    estimated,trace,stationarity=run(observed)
    raw,_=rollout_with_latent(params,observed[0],controls,.02,latent,roles,context,exo_roles)
    cost=lambda predicted:float(jnp.mean((jax.vmap(rigid_body_local_error)(predicted,observed)/scales)**2))
    clean_estimated,clean_trace,_=run(truth)
    flipped,_,_=run(observed.at[::2,6:10].multiply(-1))
    shift=jnp.asarray([2.,-3.,4.])
    translated,_,_=run(observed.at[:,:3].add(shift))
    row=dict(raw_cost=cost(raw),solved_cost=cost(estimated),stationarity=float(stationarity),
        clean_max_tangent_error=float(jnp.max(jnp.abs(jax.vmap(rigid_body_local_error)(clean_estimated,truth)))),
        antipodal_max_tangent_error=float(jnp.max(jnp.abs(jax.vmap(rigid_body_local_error)(flipped,estimated)))),
        translation_max_tangent_error=float(jnp.max(jnp.abs(jax.vmap(rigid_body_local_error)(translated.at[:,:3].add(-shift),estimated)))),
        actuator_max_error=float(jnp.max(jnp.abs(trace-true_latent))),
        observed_endpoint_mse=float(jnp.mean(noise[-1]**2)),
        reconstructed_endpoint_mse=float(jnp.mean(rigid_body_local_error(estimated[-1],truth[-1])**2)))
    assert row['solved_cost']<=row['raw_cost']
    assert row['clean_max_tangent_error']<1e-4
    assert row['antipodal_max_tangent_error']<1e-4
    assert row['translation_max_tangent_error']<1e-4
    assert row['actuator_max_error']==0
    results[family]=row
    print(family,row,flush=True)
    jax.clear_caches()
(root/'generality.json').write_text(json.dumps(results,indent=2)+'\n')
