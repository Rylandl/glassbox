import sys,json,time
from pathlib import Path
import jax
import jax.numpy as jnp
import numpy as np
sys.path.insert(0,str(Path.cwd()/'scripts'))
import evaluate_fit_uncertainty as study
from reconstruct import reconstruct
from glassbox.core.data import control_history_before,trajectory_windows
from glassbox.core.dynamics import control_state_after_history,rollout_with_latent,with_structured_parameter_vector
from glassbox.core.geometry import rigid_body_local_error
from glassbox.core.identification import rollout_loss_configuration
from glassbox.core.synthetic import true_parameters

root=Path('/tmp/glassbox-noisy-fit-investigation/confirmation')
results={}
for condition in ('noisy','noisier','collective'):
    rep=16
    clean=[study.truth_flight(100000+10*rep+i,condition=='collective') for i in range(2)]
    train=[study.noisy_trajectory(t,200000+10*rep+i,study.CONDITIONS[condition],'train') for i,t in enumerate(clean)]
    config=rollout_loss_configuration([trajectory_windows(train,horizon=25)])
    scales=jnp.asarray(np.concatenate((config.position_scale_m,config.velocity_scale_m_s,
        np.repeat(config.attitude_scale_rad/np.sqrt(3),3),config.angular_velocity_scale_rad_s)))
    @jax.jit
    def forecast(params,observed,past,prefix,future):
        initial=control_state_after_history(params,prefix,.02)
        states,latent,stationarity=reconstruct(params,observed,past,.02,initial,scales)
        predicted,_=rollout_with_latent(params,states[-1],future,.02,latent[-1])
        return predicted,stationarity
    models={'truth':true_parameters()}
    saved=np.load(root/condition/'16/arrays.npz')
    for name in ('fixed_4000','joint_4000'):
        models[name]=with_structured_parameter_vector(true_parameters(),jnp.asarray(saved[f'{name}/theta']))
    clean_test=study.truth_flight(500000,condition=='collective')
    measured=study.noisy_trajectory(clean_test,600000+10*rep,study.CONDITIONS[condition],'test')
    observed=jnp.asarray(np.stack([measured.states[t-25:t+1] for t in range(50,251,50)]))
    past=jnp.asarray(np.stack([measured.controls[t-25:t] for t in range(50,251,50)]))
    prefixes=jnp.asarray(np.stack([control_history_before(measured,t-25,50) for t in range(50,251,50)]))
    future=jnp.asarray(np.stack([measured.controls[t:t+50] for t in range(50,251,50)]))
    targets=np.stack([measured.states[t:t+51] for t in range(50,251,50)])
    batch=jax.jit(jax.vmap(forecast,in_axes=(None,0,0,0,0)))
    results[condition]={}
    for name,params in models.items():
        start=time.perf_counter();predicted,stationarity=batch(params,observed,past,prefixes,future);predicted.block_until_ready()
        cold=time.perf_counter()-start
        start=time.perf_counter()
        for _ in range(10): batch(params,observed,past,prefixes,future)[0].block_until_ready()
        elapsed=(time.perf_counter()-start)/10
        errors=np.asarray(jax.vmap(jax.vmap(rigid_body_local_error))(predicted,jnp.asarray(targets)))
        mse=np.array([np.mean(errors[:,-1,indices]**2) for indices in study.TANGENT_GROUP_INDICES.values()])
        results[condition][name]={'mse':mse.tolist(),'stationarity':np.asarray(stationarity).tolist(),'cold_s':cold,'batch_s':elapsed}
        print(condition,name,'MSE',mse,'stationarity',np.max(stationarity),'batch seconds',elapsed,flush=True)
    jax.clear_caches()
Path('/tmp/glassbox-state-reconstruction/probe.json').write_text(json.dumps(results,indent=2)+'\n')
