"""Check that extracting the common solve preserves reconstruction and fit gradients."""
import importlib.util,json
from pathlib import Path
import jax
import jax.numpy as jnp
import numpy as np
from dataclasses import replace
from reconstruct import reconstruct
from profile import make_objective
from glassbox.core.synthetic import true_parameters,initial_parameter_guess
from glassbox.core.dynamics import control_state_after_history
from glassbox.core.data import trajectory_windows
from glassbox.core.identification import rollout_loss_configuration
from paired import scales_for,study
root=Path('/tmp/glassbox-state-reconstruction')
def load(name):
    spec=importlib.util.spec_from_file_location('original_'+name,root/'executed'/f'{name}.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
original_reconstruct=load('reconstruct').reconstruct
original_objective=load('profile').make_objective
true=study.truth_flight(100160,False)
measured=study.noisy_trajectory(true,200160,1.,'train')
w=trajectory_windows([measured],horizon=25)
w=replace(w,initial_states=w.initial_states[:2],controls=w.controls[:2],target_states=w.target_states[:2],control_histories=w.control_histories[:2],initial_exogenous=w.initial_exogenous[:2])
params=initial_parameter_guess()
scales=scales_for([measured])
config=rollout_loss_configuration([w])
latent=control_state_after_history(params,jnp.asarray(w.control_histories[0]),.02)
values=[]
for f in (original_reconstruct,reconstruct):
    values.append(jax.jit(lambda: f(params,jnp.asarray(w.target_states[0]),jnp.asarray(w.controls[0]),.02,latent,scales))())
for a,b in zip(jax.tree.leaves(values[0]),jax.tree.leaves(values[1])):np.testing.assert_array_equal(a,b)
values=[]
for maker in (original_objective,make_objective):
    f=maker(w,config,scales)
    values.append(jax.jit(jax.value_and_grad(f,has_aux=True))(params))
for a,b in zip(jax.tree.leaves(values[0]),jax.tree.leaves(values[1])):np.testing.assert_array_equal(a,b)
result=dict(reconstruction='array-exact parity',profile_objective_and_gradient='array-exact parity',windows=2)
(root/'parity.json').write_text(json.dumps(result,indent=2)+'\n')
print(result)
