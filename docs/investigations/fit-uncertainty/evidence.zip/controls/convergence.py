import json,time
from pathlib import Path
import numpy as np
from glassbox.fitting import fit,FitSpec,Holdout
from glassbox.core.dynamics import structured_parameter_vector
from glassbox.core.synthetic import true_parameters
root=Path('/tmp/glassbox-fit-uncertainty-study');truth=np.asarray(structured_parameter_vector(true_parameters()))
for part,condition in [('batch-a','clean'),('batch-b','noisier')]:
 source=root/part/condition/'00';paths=sorted(source.glob('*.npz'));paths=[p for p in paths if p.name!='arrays.npz']
 start=time.monotonic();out=fit(paths,FitSpec(holdout=Holdout.by_label('role',('calibration',)),steps=4000,evaluation_horizons_s=(.1,.5,1.)))
 info=out.belief.information;i,e,v,t=info._normalized_spectrum();delta=np.asarray(structured_parameter_vector(out.belief.params))-truth
 normalized=np.mean((v[:,e>t].T@(delta/info.scale)[i])**2*e[e>t])
 report={'condition':condition,'steps':4000,'fit':out.report['models']['learned_lag']['fit'],'theta_error':delta.tolist(),'resolved_rank':info.resolved_rank(),'resolved_error_over_variance':float(normalized),'elapsed_s':time.monotonic()-start}
 (root/f'convergence-{condition}.json').write_text(json.dumps(report,indent=2)+'\n');out.belief.save(root/f'convergence-{condition}-belief.json')
 print(condition,report['elapsed_s'],'loss',report['fit']['final_loss'],'rank',info.resolved_rank(),'standardized_error',normalized,flush=True)
