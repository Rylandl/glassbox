"""Verify the archived forecast reductions, headline ratios and source identities."""
import io,json,hashlib,zipfile
from pathlib import Path
import numpy as np
root=Path('docs/investigations/noise-separation')
report=json.loads((root/'report.json').read_text())
groups={'position':slice(0,3),'velocity':slice(3,6),'attitude':slice(6,9),'angular_velocity':slice(9,12)}
with zipfile.ZipFile(root/'evidence.zip') as z:
    assert z.testzip() is None
    assert json.loads(z.read('report.json'))==report
    rows=json.loads(z.read('forecast-report.json'))
    def arrays(name):return dict(np.load(io.BytesIO(z.read('arrays/'+name+'.npz')),allow_pickle=False))
    count=0
    for name,row in rows.items():
        data=arrays(name)
        error=np.asarray(data['errors'],dtype=float)
        assert error.shape[1]==row['windows'] and np.isfinite(error).all()
        for group,ix in groups.items():
            expected=np.sum(error[...,ix]**2,axis=(1,3))/(error.shape[1]*3)
            np.testing.assert_allclose(row['mse'][group],expected,rtol=1e-12,atol=1e-20)
            count+=1
        np.testing.assert_array_equal(np.sqrt(data['r'][::3]),row['r_std'])
        np.testing.assert_array_equal(np.sqrt(data['q'][::3]),row['q_std'])
    for name,ratios in report['causal_reconstruction_mse_ratio_1s'].items():
        for group in groups:
            a=np.asarray(rows[name]['mse'][group])
            np.testing.assert_allclose(ratios[group],a[1,-1]/max(a[0,-1],1e-30),rtol=1e-12)
            count+=1
    for method,ratios in report['arp_likelihood_fit_over_current_raw_mse_1s'].items():
        for group in groups:
            expected=rows['fit-arp-'+method]['mse'][group][0][-1]/rows['arp']['mse'][group][0][-1]
            np.testing.assert_allclose(ratios[group],expected,rtol=1e-12)
            count+=1
    truth=np.asarray(report['parameter_comparison']['true_vector'])
    indices=report['parameter_comparison']['free_indices']
    for condition,metrics in report['parameter_mse'].items():
        fit=arrays('fit-'+condition+'-20')
        for name,mse in metrics.items():
            theta=arrays('horizon-control-'+condition)[name.removeprefix('horizon_100_')] if name.startswith('horizon_100_') else fit[name]
            expected=np.mean((np.asarray(theta,dtype=float)[indices]-truth[indices])**2)
            np.testing.assert_allclose(mse,expected,rtol=1e-12)
            count+=1
    for condition,ratios in report['reconstructed_start_refit_over_continued_raw_mse_1s'].items():
        for group in groups:
            expected=rows[f'polish-{condition}-reconstructed']['mse'][group][0][-1]/rows[f'polish-{condition}-continued']['mse'][group][0][-1]
            np.testing.assert_allclose(ratios[group],expected,rtol=1e-12)
            count+=1
    for name,sha in report['prototype_source_sha256'].items():assert hashlib.sha256(z.read('prototype/'+name)).hexdigest()==sha
    for name,sha in report['numerical_source_sha256'].items():assert hashlib.sha256(z.read(name)).hexdigest()==sha
print('Verified',count,'metric arrays/scalars, prototype and numerical source hashes, and archive integrity.')
