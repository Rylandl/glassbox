"""Fit dynamics and observation/transition variance using the same residual likelihood."""
import sys,json,time
from pathlib import Path
import jax
import jax.numpy as jnp
import numpy as np
sys.path.insert(0,str(Path.cwd()/'scripts'))
import evaluate_fit_uncertainty as study
from noise import filter_errors
from glassbox.core.data import trajectory_windows
from glassbox.core.dynamics import control_state_after_history,control_state_trace,step_with_latent,structured_parameter_vector,zero_angular_cross_coupling_gradient,zero_thrust_command_offset_gradient
from glassbox.core.geometry import rigid_body_local_error,state_plus_tangent
from glassbox.core.synthetic import initial_parameter_guess,true_parameters
from glassbox.core.identification import fit_dynamics,rollout_loss_configuration
from probe import evaluate

ROOT=Path('/tmp/glassbox-noise-separation')

def fit_likelihood(train):
    windows=trajectory_windows(train,horizon=100)
    obs=jnp.asarray(windows.target_states)
    commands=jnp.asarray(windows.controls)
    history=jnp.asarray(windows.control_histories)
    roles=windows.control_roles;dt=windows.dt_s
    def one(params,observed,controls,prefix):
        initial=control_state_after_history(params,prefix,dt,roles)
        applied=control_state_trace(params,controls,dt,roles,initial)
        def step(state,target,latent,control):
            def error(offset):
                predicted=step_with_latent(params,state_plus_tangent(state,offset),latent,control,dt,roles)[0]
                return rigid_body_local_error(target,predicted)
            return error(jnp.zeros(12)),jax.jacfwd(error)(jnp.zeros(12))
        return jax.vmap(step)(observed[:-1],observed[1:],applied[:-1],controls)
    batch=jax.vmap(one,in_axes=(None,0,0,0))
    initial=initial_parameter_guess()
    initial_d,_=batch(initial,obs,commands,history)
    scales=jax.lax.stop_gradient(jnp.maximum(jnp.mean(initial_d**2,axis=(0,1)).reshape(4,3).mean(axis=1),1e-12))
    def objective(variables):
        params,noise=variables
        d,a=batch(params,obs,commands,history)
        r=jnp.repeat(scales*jnp.exp(noise[:4]),3)
        q=jnp.repeat(scales*jnp.exp(noise[4:]),3)
        return jnp.mean(jax.vmap(lambda d,a:filter_errors(d,a,r,q)[1])(d,a))
    value_grad=jax.value_and_grad(objective)
    @jax.jit
    def update(variables,first,second,index):
        value,(gp,gn)=value_grad(variables)
        gp=zero_thrust_command_offset_gradient(zero_angular_cross_coupling_gradient(gp))
        gradient=(gp,gn)
        norm=jnp.sqrt(sum(jnp.sum(a*a) for a in jax.tree.leaves(gradient)))
        gradient=jax.tree.map(lambda g:g*jnp.minimum(1.,10./(norm+1e-12)),gradient)
        first=jax.tree.map(lambda a,g:.9*a+.1*g,first,gradient)
        second=jax.tree.map(lambda a,g:.999*a+.001*g*g,second,gradient)
        variables=jax.tree.map(lambda p,a,b:p-.02*(a/(1-.9**index))/(jnp.sqrt(b/(1-.999**index))+1e-8),variables,first,second)
        variables=variables[0],jnp.clip(variables[1],-20,5)
        return variables,first,second,value
    variables=initial,jnp.full(8,-.7)
    first=jax.tree.map(jnp.zeros_like,variables);second=first
    start=time.monotonic();models={};losses=[]
    for i in range(1,1001):
        variables,first,second,value=update(variables,first,second,i)
        losses.append(float(value))
        if i in (100,400,1000):
            models[f'likelihood_{i}']=variables[0]
            error=np.asarray(structured_parameter_vector(variables[0]))-np.asarray(structured_parameter_vector(true_parameters()))
            print('step',i,'loss',float(value),'parameter mse',float(np.mean(error[[0,2,3,4,5,6,7,8,9]]**2)),'seconds',time.monotonic()-start,flush=True)
    return models,variables[1],scales,losses

if __name__=='__main__':
    condition=sys.argv[1] if len(sys.argv)>1 else 'noisy'
    rep=int(sys.argv[2]) if len(sys.argv)>2 else 20
    clean=[study.truth_flight(100000+10*rep+i,condition=='collective') for i in range(2)]
    train=[study.noisy_trajectory(t,200000+10*rep+i,study.CONDITIONS[condition],'train') for i,t in enumerate(clean)]
    models,noise,scale,loss=fit_likelihood(train)
    w=trajectory_windows(train,horizon=25)
    for steps in (400,1000):
        result=fit_dynamics([w],initial_parameter_guess(),steps=steps,learning_rate=.02,diagonal_angular_control=True)
        models[f'fixed_{steps}']=result.params
        print('fixed',steps,'parameter mse',float(np.mean((np.asarray(structured_parameter_vector(result.params))[[0,2,3,4,5,6,7,8,9]]-np.asarray(structured_parameter_vector(true_parameters()))[[0,2,3,4,5,6,7,8,9]])**2)),flush=True)
    true=[study.truth_flight(700000+i,condition=='collective') for i in range(3)]
    tests=[study.noisy_trajectory(t,800000+10*rep+i,study.CONDITIONS[condition],'test') for i,t in enumerate(true)]
    np.savez_compressed(ROOT/f'fit-{condition}-{rep}.npz',**{k:np.asarray(structured_parameter_vector(p)) for k,p in models.items()},noise=np.asarray(noise),scale=np.asarray(scale),loss=loss)
    for name in ('likelihood_400','likelihood_1000','fixed_400','fixed_1000'):
        evaluate(models[name],train,tests,f'fit-{condition}-{rep}-{name}')
