"""Check the likelihood and smoothing recurrences against dense Gaussian conditioning."""
import json
from pathlib import Path
import jax
import jax.numpy as jnp
import numpy as np
from noise import filter_errors,fit_noise
from polish import smooth_initial
rng=np.random.default_rng(815)
n=5;size=12
r=np.repeat(np.array([.002,.02,.002,.01])**2,3)
q=.4*r
A=.94*np.eye(size)[None]+.005*rng.normal(size=(n,size,size))
e=rng.normal(size=(n+1,size))*np.sqrt(r)
w=rng.normal(size=(n,size))*np.sqrt(q)
d=np.einsum('nij,nj->ni',A,e[:-1])-e[1:]+w
S=np.zeros((n*size,n*size))
R=np.diag(r);Q=np.diag(q)
for t in range(n):
    s=slice(t*size,(t+1)*size)
    S[s,s]=A[t]@R@A[t].T+R+Q
    if t:
        prev=slice((t-1)*size,t*size)
        S[s,prev]=-A[t]@R;S[prev,s]=-R@A[t].T
solution=np.linalg.solve(S,d.ravel())
expected=(np.linalg.slogdet(S)[1]+d.ravel()@solution)/(size*n)
means,losses=filter_errors(jnp.asarray(d),jnp.asarray(A),jnp.asarray(r),jnp.asarray(q))
np.testing.assert_allclose(np.mean(losses),expected,rtol=2e-6)
np.testing.assert_allclose(means[-1],-R@solution[-size:],rtol=1e-5,atol=1e-8)
initial=smooth_initial(jnp.asarray(d),jnp.asarray(A),jnp.asarray(r),jnp.asarray(q))
np.testing.assert_allclose(initial,R@A[0].T@solution[:size],rtol=1e-5,atol=1e-8)
N=3000
A=np.repeat((.94*np.eye(size))[None],N,axis=0)
e=rng.normal(size=(N+1,size))*np.sqrt(r)
w=rng.normal(size=(N,size))*np.sqrt(q)
d=np.einsum('nij,nj->ni',A,e[:-1])-e[1:]+w
fit_r,fit_q,loss=fit_noise([(d,A,None)])
print('R standard-deviation ratio',np.sqrt(fit_r/r)[::3])
print('Q standard-deviation ratio',np.sqrt(fit_q/q)[::3])
np.testing.assert_allclose(np.sqrt(fit_r/r),1.,atol=.08)
np.testing.assert_allclose(np.sqrt(fit_q/q),1.,atol=.08)
report=dict(dense_likelihood_absolute_error=abs(float(np.mean(losses))-expected),
    initial_and_terminal_conditioning='matches dense Gaussian conditioning',
    independent_process_and_observation_noise_samples=N,
    r_std_ratio=np.sqrt(fit_r/r)[::3].tolist(),q_std_ratio=np.sqrt(fit_q/q)[::3].tolist())
Path('/tmp/glassbox-noise-separation/linear-check.json').write_text(json.dumps(report,indent=2)+'\n')
