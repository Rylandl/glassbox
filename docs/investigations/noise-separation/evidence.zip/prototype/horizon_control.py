from pathlib import Path
import jax
import numpy as np
from fit_probe import study
from glassbox.core.data import trajectory_windows
from glassbox.core.identification import fit_dynamics
from glassbox.core.synthetic import initial_parameter_guess,true_parameters
from glassbox.core.dynamics import structured_parameter_vector
root=Path('/tmp/glassbox-noise-separation')
for condition in ('noisy','noisier'):
    rep=20
    true=[study.truth_flight(100000+10*rep+i,False) for i in range(2)]
    train=[study.noisy_trajectory(t,200000+10*rep+i,study.CONDITIONS[condition],'train') for i,t in enumerate(true)]
    w=trajectory_windows(train,horizon=100)
    arrays={}
    for steps in (400,1000):
        fit=fit_dynamics([w],initial_parameter_guess(),steps=steps,learning_rate=.02,diagonal_angular_control=True)
        a=np.asarray(structured_parameter_vector(fit.params));arrays[f'fixed_{steps}']=a
        error=a-np.asarray(structured_parameter_vector(true_parameters()))
        print(condition,steps,float(np.mean(error[[0,2,3,4,5,6,7,8,9]]**2)),flush=True)
    np.savez_compressed(root/f'horizon-control-{condition}.npz',**arrays)
    jax.clear_caches()
