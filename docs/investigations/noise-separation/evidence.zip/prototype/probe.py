import json,sys,time
from pathlib import Path
import jax
import jax.numpy as jnp
import numpy as np
sys.path.insert(0,str(Path.cwd()/'scripts'))
import evaluate_fit_uncertainty as study
from noise import linearize,fit_noise,reconstruct
from glassbox.core.data import load_trajectory_npz,control_history_before
from glassbox.core.dynamics import rollout_with_latent,with_structured_parameter_vector,control_state_after_history
from glassbox.core.model import ExecutableModel
from glassbox.core.synthetic import true_parameters,initial_parameter_guess
from glassbox.core.geometry import rigid_body_local_error

ROOT=Path('/tmp/glassbox-noise-separation')

def evaluate(params,train,tests,name):
    start=time.monotonic()
    train_data=[linearize(params,t) for t in train]
    r,q,loss=fit_noise(train_data)
    print(name,'R sd',np.sqrt(r[::3]),'Q sd',np.sqrt(q[::3]),'nll',loss[0],loss[-1],flush=True)
    output={};errors=[]
    for t in tests:
        data=linearize(params,t)
        estimated,latent,nll=reconstruct(t,data,r,q)
        starts=np.arange(0,len(t.controls)-49,50)
        controls=jnp.asarray(np.stack([t.controls[s:s+50] for s in starts]))
        observed=jnp.asarray(np.stack([t.states[s:s+51] for s in starts]))
        context=jnp.asarray(np.stack([t.exogenous[s:s+50] for s in starts]))
        initial=jnp.asarray(np.stack((t.states[starts],estimated[starts])))
        # Same continuous actuator history for both initialization methods.
        applied=jnp.asarray(latent[starts])
        run=jax.jit(jax.vmap(jax.vmap(lambda x,u,m,c:rollout_with_latent(params,x,u,t.nominal_dt_s,m,t.spec.control_roles,c,t.spec.exogenous_roles)[0]),in_axes=(0,None,None,None)))
        predicted=run(initial,controls,applied,context)
        error=jax.vmap(jax.vmap(jax.vmap(rigid_body_local_error)),in_axes=(0,None))(predicted,observed)
        errors.append(np.asarray(error[:,:,jnp.asarray((5,25,50)),:]))
    errors=np.concatenate(errors,axis=1)
    mse=np.stack([np.mean(errors[...,idx]**2,axis=(1,3)) for idx in study.TANGENT_GROUP_INDICES.values()],axis=1)
    print(name,'1s ratio',(mse[1,:,-1]/np.maximum(mse[0,:,-1],1e-30)).tolist(),'seconds',time.monotonic()-start,flush=True)
    np.savez_compressed(ROOT/f'{name}.npz',r=r,q=q,loss=loss,errors=errors)
    return {'r_std':np.sqrt(r[::3]).tolist(),'q_std':np.sqrt(q[::3]).tolist(),'mse':mse.tolist(),'fit_seconds':time.monotonic()-start}

if __name__=='__main__':
    mode=sys.argv[1] if len(sys.argv)>1 else 'noisy'
    if mode=='arp':
        paths=sorted(Path('artifacts/arp_reference/canonical').glob('*.npz'))
        t=[load_trajectory_npz(p) for p in paths]
        results={'arp':evaluate(ExecutableModel.load('artifacts/arp_reference/model.json').params,t[:3],t[3:],'arp')}
    else:
        rep=20
        clean=[study.truth_flight(100000+10*rep+i,mode=='collective') for i in range(2)]
        train=[study.noisy_trajectory(t,200000+10*rep+i,study.CONDITIONS[mode],'train') for i,t in enumerate(clean)]
        clean_test=[study.truth_flight(700000+i,mode=='collective') for i in range(3)]
        tests=[study.noisy_trajectory(t,800000+10*rep+i,study.CONDITIONS[mode],'test') for i,t in enumerate(clean_test)]
        saved=np.load(Path('/tmp/glassbox-noisy-fit-investigation/confirmation')/mode/'16/arrays.npz')
        models={'truth':true_parameters(),'wrong':initial_parameter_guess(),'joint':with_structured_parameter_vector(true_parameters(),jnp.asarray(saved['joint_4000/theta']))}
        results={}
        for name,p in models.items():
            results[name]=evaluate(p,train,tests,f'{mode}-{name}')
            jax.clear_caches()
    (ROOT/f'{mode}-report.json').write_text(json.dumps(results,indent=2)+'\n')
