"""Fit observation and transition variance through adjacent residual dependence."""
import jax
import jax.numpy as jnp
import numpy as np
from glassbox.core.data import control_history_before
from glassbox.core.dynamics import control_state_after_history,control_state_trace,step_with_latent
from glassbox.core.geometry import rigid_body_local_error,state_plus_tangent


def linearize(params,t):
    dt=t.nominal_dt_s;roles=t.spec.control_roles;exo_roles=t.spec.exogenous_roles
    history=control_history_before(t,0,round(1/dt))
    initial=control_state_after_history(params,jnp.asarray(history),dt,roles)
    latent=control_state_trace(params,jnp.asarray(t.controls),dt,roles,initial)
    def one(state,target,applied,control,context):
        def residual(offset):
            predicted=step_with_latent(params,state_plus_tangent(state,offset),applied,control,dt,roles,context,exo_roles)[0]
            return rigid_body_local_error(target,predicted)
        return residual(jnp.zeros(12)),jax.jacfwd(residual)(jnp.zeros(12))
    d,a=jax.jit(jax.vmap(one))(jnp.asarray(t.states[:-1]),jnp.asarray(t.states[1:]),latent[:-1],jnp.asarray(t.controls),jnp.asarray(t.exogenous[:-1]))
    return np.asarray(d),np.asarray(a),np.asarray(latent)


def filter_errors(d,a,r,q):
    r=jnp.diag(r);q=jnp.diag(q)
    def step(carry,values):
        mean,cov=carry;difference,transition=values
        residual=difference-transition@mean
        s=transition@cov@transition.T+r+q
        # Simultaneously solve for the innovation and the measurement covariance.
        solutions=jnp.linalg.solve(s,jnp.concatenate((residual[:,None],r),axis=1))
        next_mean=-r@solutions[:,0]
        next_cov=r-r@solutions[:,1:]
        next_cov=(next_cov+next_cov.T)*.5
        loss=(jnp.linalg.slogdet(s)[1]+residual@solutions[:,0])/12
        return (next_mean,next_cov),(next_mean,loss)
    return jax.lax.scan(step,(jnp.zeros(12),r),(d,a))[1]


def fit_noise(data):
    # Equal-flight weighting. Blocks bound reverse-mode memory and start from R.
    blocks=[];jac=[];weights=[]
    for d,a,_ in data:
        count=len(d)//100
        blocks.extend(d[:count*100].reshape(count,100,12))
        jac.extend(a[:count*100].reshape(count,100,12,12))
        weights.extend([1/count]*count)
    d=jnp.asarray(np.stack(blocks));a=jnp.asarray(np.stack(jac));weights=jnp.asarray(weights)
    scale=jnp.maximum(jnp.mean(d*d,axis=(0,1)).reshape(4,3).mean(axis=1),1e-12)
    def covariance(log_scale):
        return jnp.repeat(scale*jnp.exp(log_scale[:4]),3),jnp.repeat(scale*jnp.exp(log_scale[4:]),3)
    def objective(theta):
        r,q=covariance(theta)
        losses=jax.vmap(lambda d,a:filter_errors(d,a,r,q)[1].mean())(d,a)
        return jnp.sum(losses*weights)/jnp.sum(weights)
    vg=jax.jit(jax.value_and_grad(objective))
    theta=jnp.full(8,-.7);first=jnp.zeros(8);second=jnp.zeros(8)
    losses=[]
    for i in range(1,501):
        loss,g=vg(theta)
        first=.9*first+.1*g;second=.999*second+.001*g*g
        theta=jnp.clip(theta-.05*(first/(1-.9**i))/(jnp.sqrt(second/(1-.999**i))+1e-8),-20,5)
        losses.append(float(loss))
    r,q=covariance(theta)
    return np.asarray(r),np.asarray(q),losses


def reconstruct(t,linearization,r,q):
    d,a,latent=linearization
    errors,losses=jax.jit(filter_errors)(jnp.asarray(d),jnp.asarray(a),jnp.asarray(r),jnp.asarray(q))
    estimates=jax.vmap(state_plus_tangent)(jnp.asarray(t.states[1:]),-errors)
    return np.concatenate((t.states[:1],np.asarray(estimates))),latent,np.asarray(losses)
