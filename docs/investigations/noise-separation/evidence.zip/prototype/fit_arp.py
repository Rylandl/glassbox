import json,time
from pathlib import Path
import numpy as np
from glassbox.core.data import load_trajectory_npz
from glassbox.core.dynamics import structured_parameter_vector
from fit_probe import fit_likelihood
from probe import evaluate
root=Path('/tmp/glassbox-noise-separation')
t=[load_trajectory_npz(p) for p in sorted(Path('artifacts/arp_reference/canonical').glob('*.npz'))]
models,noise,scale,loss=fit_likelihood(t[:3])
np.savez_compressed(root/'fit-arp.npz',**{k:np.asarray(structured_parameter_vector(p)) for k,p in models.items()},noise=np.asarray(noise),scale=np.asarray(scale),loss=loss)
for name in ('likelihood_400','likelihood_1000'):
    evaluate(models[name],t[:3],t[3:],f'fit-arp-{name}')
