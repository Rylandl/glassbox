"""Build compact findings and complete per-array reductions for the noise probes."""
import hashlib,json,platform,sys
from pathlib import Path
import jax
import numpy as np
from glassbox.core.synthetic import true_parameters
from glassbox.core.dynamics import structured_parameter_vector,structured_parameter_names
root=Path('/tmp/glassbox-noise-separation')
truth=np.asarray(structured_parameter_vector(true_parameters()),dtype=float)
indices=[0,2,3,4,5,6,7,8,9]
groups={'position':slice(0,3),'velocity':slice(3,6),'attitude':slice(6,9),'angular_velocity':slice(9,12)}
forecast={}
for path in sorted(root.glob('*.npz')):
    data=dict(np.load(path,allow_pickle=False))
    if 'errors' not in data:continue
    errors=np.asarray(data['errors'],dtype=float)
    assert errors.shape[0]==2 and errors.shape[2:]==(3,12)
    assert np.all(np.isfinite(errors))
    mse={g:np.mean(errors[...,ix]**2,axis=(1,3)).tolist() for g,ix in groups.items()}
    forecast[path.stem]={'windows':errors.shape[1],'mse':mse,'r_std':np.sqrt(data['r'][::3]).tolist(),'q_std':np.sqrt(data['q'][::3]).tolist()}

def ratios(candidate,baseline,initialization=0,baseline_initialization=0):
    a=forecast[candidate]['mse'];b=forecast[baseline]['mse']
    return {g:float(a[g][initialization][-1]/max(b[g][baseline_initialization][-1],1e-30)) for g in groups}

fits={}
for condition in ('clean','noisy','noisier','collective'):
    data=dict(np.load(root/f'fit-{condition}-20.npz'))
    fits[condition]={method:float(np.mean((np.asarray(theta,dtype=float)[indices]-truth[indices])**2)) for method,theta in data.items() if method.startswith(('likelihood_','fixed_'))}
    other=root/f'horizon-control-{condition}.npz'
    if other.exists():
        for method,theta in dict(np.load(other)).items():
            fits[condition]['horizon_100_'+method]=float(np.mean((np.asarray(theta,dtype=float)[indices]-truth[indices])**2))
report={
    'design':{
        'model':'existing quadrotor dynamics and 12-coordinate local geometry',
        'sample_period_s':.02,
        'covariance_model':'d_t = A_t e_t - e_(t+1) + w_t; independent zero-mean observation e and transition w terms',
        'variance_parameters':'one observation and one transition variance per existing state group; eight nonnegative nuisance variances',
        'fit_noise':'500 Adam steps at .05; equally weighted training flights; 100-transition blocks; no test data used',
        'synthetic':'one fresh training replicate (20) per condition; two six-second flights; truth seed 100200+i, observation seed 200200+i',
        'noise_std':[.002,.02,.002,.01],
        'conditions':{'clean':0,'noisy':1,'noisier':3,'collective':1},
        'collective':'equal motor commands and zero true angular motion',
        'tests':'three six-second command designs, truth seeds 700000+i; observation seeds 800200+i; i=0,1,2',
        'forecast':'1-second windows; complete causal state/actuator history; cold start retains first observation; score observed targets at .1, .5 and 1 seconds',
        'initialization_order':['raw','covariance-weighted causal reconstruction'],
        'likelihood_fit':'joint dynamics and eight variances, 100-transition windows; 1000 Adam steps at .02, checkpoints at 400 and 1000',
        'fixed_fit':'existing rollout loss, 25-transition windows; independent 400- and 1000-step runs at .02; additional 100-transition controls for both excited noise conditions',
        'optimizer_in_probes':'final-iterate selection, preceding the production best-iterate fix',
        'arp':'training logs 63,64,65 and reserved log 66; the current history-corrected artifact supplies the initial fixed-model probe',
        'scope':'exploratory single-fit comparisons; all windows, no support filtering; no parameter truth is assumed for ARP',
        'jax_version':jax.__version__,'x64':bool(jax.config.jax_enable_x64),'python':platform.python_version(),
    },
    'known_model_observation_std_estimates':{condition:forecast[f'{condition}-truth']['r_std'] for condition in ('noisy','noisier','collective')},
    'causal_reconstruction_mse_ratio_1s':{name:ratios(name,name,1) for name in ('noisy-truth','noisy-wrong','noisy-joint','noisier-truth','noisier-wrong','noisier-joint','collective-truth','collective-wrong','collective-joint','arp')},
    'parameter_mse':fits,
    'parameter_comparison':{'names':structured_parameter_names(true_parameters()),'free_indices':indices,'true_vector':truth.tolist(),'collective_note':'angular coordinates have no driven true response; their aggregate error does not measure recovery of excited dynamics'},
    'arp_likelihood_fit_over_current_raw_mse_1s':{method:ratios(f'fit-arp-{method}','arp') for method in ('likelihood_400','likelihood_1000')},
    'reconstructed_start_refit_over_continued_raw_mse_1s':{condition:ratios(f'polish-{condition}-reconstructed',f'polish-{condition}-continued') for condition in ('noisy','arp')},
    'linear_control':json.loads((root/'linear-check.json').read_text()),
    'decision':'retain multi-step prediction fitting; covariance estimation and reconstructed-start refits remain experimental. Production fixes separate adjacent/nonadjacent residual structure, preserve missing-interval timing, and retain the best evaluated full-batch iterate.',
    'evidence':'the archive includes every reduced forecast array, fitted vectors, exact prototype sources, numerical source snapshot, and per-array metrics',
}
(root/'forecast-report.json').write_text(json.dumps(forecast,indent=2,allow_nan=False)+'\n')
(root/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print('Forecast cases',len(forecast))
print('ARP likelihood ratios',report['arp_likelihood_fit_over_current_raw_mse_1s'])
print('Start-refit ratios',report['reconstructed_start_refit_over_continued_raw_mse_1s'])
