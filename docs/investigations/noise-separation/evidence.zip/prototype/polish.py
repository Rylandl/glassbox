"""Use estimated observation/transition weights to reconstruct starts, retaining rollout fitting."""
import sys,json,time
from pathlib import Path
from dataclasses import replace
import jax
import jax.numpy as jnp
import numpy as np
from fit_probe import study
from noise import linearize,fit_noise
from glassbox.core.data import trajectory_windows,load_trajectory_npz
from glassbox.core.dynamics import control_state_after_history,control_state_trace,step_with_latent,structured_parameter_vector,with_structured_parameter_vector
from glassbox.core.geometry import rigid_body_local_error,state_plus_tangent
from glassbox.core.synthetic import true_parameters
from glassbox.core.model import ExecutableModel
from glassbox.core.identification import fit_dynamics,rollout_loss_configuration
from probe import evaluate

ROOT=Path('/tmp/glassbox-noise-separation')

def smooth_initial(d,a,r,q):
    r=jnp.diag(r);q=jnp.diag(q)
    def forward(carry,values):
        mean,p=carry;delta,a=values
        predicted_mean=a@mean-delta
        predicted_p=a@p@a.T+q
        s=predicted_p+r
        kr=jnp.linalg.solve(s,r).T
        next_mean=kr@predicted_mean
        next_p=r-kr@r
        next_p=.5*(next_p+next_p.T)
        gain=jnp.linalg.solve(predicted_p,a@p).T
        return (next_mean,next_p),(mean,predicted_mean,gain)
    (last,_),saved=jax.lax.scan(forward,(jnp.zeros(12),r),(d,a))
    def backward(next_mean,values):
        mean,predicted_mean,gain=values
        smoothed=mean+gain@(next_mean-predicted_mean)
        return smoothed,None
    return jax.lax.scan(backward,last,saved,reverse=True)[0]


def reconstructed_windows(params,w,r,q):
    def one(observed,controls,history,context):
        initial=control_state_after_history(params,history,w.dt_s,w.control_roles)
        latent=control_state_trace(params,controls,w.dt_s,w.control_roles,initial)
        def residual(state,target,applied,u):
            def f(offset):
                prediction=step_with_latent(params,state_plus_tangent(state,offset),applied,u,w.dt_s,w.control_roles,context,w.exogenous_roles)[0]
                return rigid_body_local_error(target,prediction)
            return f(jnp.zeros(12)),jax.jacfwd(f)(jnp.zeros(12))
        d,a=jax.vmap(residual)(observed[:-1],observed[1:],latent[:-1],controls)
        error=smooth_initial(d,a,jnp.asarray(r),jnp.asarray(q))
        return state_plus_tangent(observed[0],-error)
    initial=jax.jit(jax.vmap(one))(jnp.asarray(w.target_states),jnp.asarray(w.controls),jnp.asarray(w.control_histories),jnp.asarray(w.initial_exogenous))
    return replace(w,initial_states=np.asarray(initial))


def run(condition,rep=20):
    if condition=='arp':
        t=[load_trajectory_npz(p) for p in sorted(Path('artifacts/arp_reference/canonical').glob('*.npz'))]
        train=t[:3];tests=t[3:];horizons=(5,25,100)
        params=ExecutableModel.load('artifacts/arp_reference/model.json').params
    else:
        clean=[study.truth_flight(100000+10*rep+i,condition=='collective') for i in range(2)]
        train=[study.noisy_trajectory(t,200000+10*rep+i,study.CONDITIONS[condition],'train') for i,t in enumerate(clean)]
        true=[study.truth_flight(700000+i,condition=='collective') for i in range(3)]
        tests=[study.noisy_trajectory(t,800000+10*rep+i,study.CONDITIONS[condition],'test') for i,t in enumerate(true)]
        saved=np.load(ROOT/f'fit-{condition}-{rep}.npz')
        params=with_structured_parameter_vector(true_parameters(),jnp.asarray(saved['fixed_400']))
        horizons=(25,)
    r,q,_=fit_noise([linearize(params,t) for t in train])
    windows=[trajectory_windows(train,horizon=h) for h in horizons]
    config=rollout_loss_configuration(windows)
    corrected=[reconstructed_windows(params,w,r,q) for w in windows]
    models={'baseline':params}
    for name,w in (('continued',windows),('reconstructed',corrected)):
        start=time.monotonic()
        result=fit_dynamics(w,params,steps=400,learning_rate=.02,diagonal_angular_control=True,loss_configuration=config)
        models[name]=result.params
        print(condition,name,'seconds',time.monotonic()-start,'loss',result.initial_loss,result.final_loss,flush=True)
    np.savez_compressed(ROOT/f'polish-{condition}.npz',**{k:np.asarray(structured_parameter_vector(p)) for k,p in models.items()},r=r,q=q)
    for name,p in models.items():
        evaluate(p,train,tests,f'polish-{condition}-{name}')

if __name__=='__main__':run(sys.argv[1] if len(sys.argv)>1 else 'noisy')
