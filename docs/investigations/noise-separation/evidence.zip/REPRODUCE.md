# Noise separation probes

Run from the repository root using the archived `src` snapshot on
`PYTHONPATH` and the repository virtual environment. Copy `prototype/*.py`
to `/tmp/glassbox-noise-separation/`. Restore `previous/` beneath
`/tmp/glassbox-noisy-fit-investigation/confirmation/`. The unchanged ARP
canonical files are in the preceding state-reconstruction evidence archive;
restore them and `arp/model.json` beneath `artifacts/arp_reference/`.

- `probe.py CONDITION`: fit covariance weights, then score causal reconstruction.
- `fit_probe.py CONDITION`: joint dynamics/variance likelihood and rollout controls.
- `fit_arp.py`: the joint fit on ARP. Its common progress logger prints a synthetic
  parameter reference; those numbers are not used in the ARP report.
- `horizon_control.py`: rollout controls at the likelihood fit's window length.
- `polish.py CONDITION`: original objective with reconstructed starts or extra steps.
- `check_linear.py`: independent dense Gaussian conditioning and known-noise checks.
- `summarize.py`: reduce the arrays to reports.

Synthetic conditions are `clean`, `noisy`, `noisier`, and `collective`;
`probe.py` and `polish.py` also accept `arp`. The source snapshot predates the
production best-iterate fix. All reported fitting probes use that optimizer.
