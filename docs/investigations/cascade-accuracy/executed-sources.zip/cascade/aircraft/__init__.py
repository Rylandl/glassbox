"""Packaged aircraft specifications."""
