import sys,json,time
from pathlib import Path
from dataclasses import replace
import jax
import jax.numpy as jnp
import numpy as np
sys.path.insert(0,str(Path.cwd()/'scripts'))
import evaluate_fit_uncertainty as study
from glassbox.core.data import trajectory_windows
from glassbox.core.synthetic import initial_parameter_guess, true_parameters
from glassbox.core.dynamics import structured_parameter_vector, zero_angular_cross_coupling_gradient, zero_thrust_command_offset_gradient
from glassbox.core.geometry import state_plus_tangent
from glassbox.core.identification import batch_rollout_loss,rollout_loss_configuration,fit_dynamics

root=Path('/tmp/glassbox-noisy-fit-investigation')
truth=np.asarray(structured_parameter_vector(true_parameters()))
for condition in ['clean','noisier','collective']:
    clean=[study.truth_flight(100000+i,condition=='collective') for i in range(2)]
    measured=[study.noisy_trajectory(t,200000+i,study.CONDITIONS[condition],'train') for i,t in enumerate(clean)]
    w=trajectory_windows(measured,horizon=25,stride=25)
    correct=trajectory_windows(clean,horizon=25,stride=25)
    config=rollout_loss_configuration([w])
    scales=jnp.asarray(np.concatenate([config.position_scale_m,config.velocity_scale_m_s,np.repeat(config.attitude_scale_rad,3),config.angular_velocity_scale_rad_s]))
    arrays=[jnp.asarray(x) for x in [w.initial_states,w.control_histories,w.controls,w.target_states]]
    def loss(params,initials):
        return batch_rollout_loss(params,initials,*arrays[1:],w.dt_s,config,control_roles=w.control_roles)
    normalizer=loss(initial_parameter_guess(),arrays[0])
    def objective(variables):
        params,corrections=variables
        starts=jax.vmap(state_plus_tangent)(arrays[0],corrections*scales)
        initial_error=.25*jnp.mean(jnp.mean(corrections[:,:3]**2,axis=1)+jnp.mean(corrections[:,3:6]**2,axis=1)+jnp.sum(corrections[:,6:9]**2,axis=1)+jnp.mean(corrections[:,9:]**2,axis=1))
        return (loss(params,starts)+initial_error/(25*2))/normalizer
    vg=jax.value_and_grad(objective)
    @jax.jit
    def step(variables,m,v,index):
        value,gradient=vg(variables)
        gp,gs=gradient
        gp=zero_angular_cross_coupling_gradient(zero_thrust_command_offset_gradient(gp))
        gradient=(gp,gs)
        norm=jnp.sqrt(sum(jnp.sum(x*x) for x in jax.tree.leaves(gradient)))
        gradient=jax.tree.map(lambda g:g*jnp.minimum(1.,10./(norm+1e-12)),gradient)
        m=jax.tree.map(lambda a,g:.9*a+.1*g,m,gradient)
        v=jax.tree.map(lambda a,g:.999*a+.001*g*g,v,gradient)
        variables=jax.tree.map(lambda p,a,b:p-.02*(a/(1-.9**index))/(jnp.sqrt(b/(1-.999**index))+1e-8),variables,m,v)
        return variables,m,v,value
    variables=(initial_parameter_guess(),jnp.zeros((len(w.initial_states),12)))
    m=jax.tree.map(jnp.zeros_like,variables);v=m
    start=time.monotonic();rows={}
    for index in range(1,4001):
        variables,m,v,value=step(variables,m,v,index)
        if index in (400,1000,4000):
            error=np.asarray(structured_parameter_vector(variables[0]))-truth
            rows[str(index)]={'error':error.tolist(),'loss':float(objective(variables)),'fixed_start_loss':float(loss(variables[0],arrays[0])/normalizer),'initial_correction_rms':np.sqrt(np.mean(np.asarray(variables[1]*scales)**2,axis=0)).tolist()}
            print(condition,'joint',index,'error',np.round(error[:10],3),'loss',rows[str(index)]['loss'],flush=True)
    oracle=fit_dynamics([replace(w,initial_states=correct.initial_states)],initial_parameter_guess(),steps=4000,learning_rate=.02,diagonal_angular_control=True,loss_configuration=config)
    rows['oracle']={'error':(np.asarray(structured_parameter_vector(oracle.params))-truth).tolist(),'loss':oracle.final_loss}
    print(condition,'oracle',np.round(rows['oracle']['error'][:10],3),'seconds',time.monotonic()-start,flush=True)
    (root/f'prototype-{condition}.json').write_text(json.dumps(rows,indent=2)+'\n')
    jax.clear_caches()
