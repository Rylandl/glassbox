import sys,json
from pathlib import Path
import jax
import jax.numpy as jnp
import numpy as np
sys.path.insert(0,str(Path.cwd()/'scripts'))
import evaluate_fit_uncertainty as study
from glassbox import DynamicsBelief
from glassbox.core.data import trajectory_windows
from glassbox.core.dynamics import with_structured_parameter_vector,structured_parameter_vector,control_state_after_history,rollout_with_latent
from glassbox.core.synthetic import true_parameters
from glassbox.core.geometry import rigid_body_local_error
root=Path('/tmp/glassbox-noisy-fit-investigation')
@jax.jit
def errors(params,initial,histories,controls,targets):
    def one(state,history,control,target):
        latent=control_state_after_history(params,history,.02)
        states,_=rollout_with_latent(params,state,control,.02,latent)
        return jax.vmap(rigid_body_local_error)(states,target)[jnp.asarray([5,25,50])]
    return jax.vmap(one)(initial,histories,controls,targets)
report={}
for condition in ['clean','noisier','collective']:
    clean=[study.truth_flight(300000+i,condition=='collective') for i in range(3)]
    observed=[study.noisy_trajectory(t,400000+i,study.CONDITIONS[condition],'test') for i,t in enumerate(clean)]
    truth=trajectory_windows(clean,horizon=50)
    measured=trajectory_windows(observed,horizon=50)
    before=DynamicsBelief.load(Path('/tmp/glassbox-fit-uncertainty-study/full')/condition/'00/belief.json').params
    models={'before':before}
    for steps in ('400','4000'):
        delta=np.asarray(json.loads((root/f'prototype-{condition}.json').read_text())[steps]['error'])
        models[steps]=with_structured_parameter_vector(true_parameters(),structured_parameter_vector(true_parameters())+jnp.asarray(delta))
    report[condition]={}
    for initial_mode,w in [('observed',measured),('truth',truth)]:
        report[condition][initial_mode]={}
        for name,p in models.items():
            e=np.asarray(errors(p,w.initial_states,w.control_histories,w.controls,measured.target_states if initial_mode=='observed' else truth.target_states))
            mse=np.stack([np.mean(e[...,indices]**2,axis=(0,2)) for indices in study.TANGENT_GROUP_INDICES.values()])
            report[condition][initial_mode][name]=mse.tolist()
        old=np.asarray(report[condition][initial_mode]['before'])
        print(condition,initial_mode,'candidate400/before',np.round(np.asarray(report[condition][initial_mode]['400'])[:,-1]/old[:,-1],3),'candidate4000/before',np.round(np.asarray(report[condition][initial_mode]['4000'])[:,-1]/old[:,-1],3),flush=True)
(root/'prototype-prediction.json').write_text(json.dumps(report,indent=2)+'\n')
