"""Recompute paired prediction comparisons and their common operating support."""
import itertools
import json
import sys
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np
sys.path.insert(0, str(Path.cwd()/'scripts'))
import evaluate_fit_uncertainty as study
from glassbox.core.data import trajectory_windows
from glassbox.core.dynamics import control_state_after_history, rollout_with_latent, with_structured_parameter_vector
from glassbox.core.geometry import quaternion_to_rotation_matrices
from glassbox.core.identification import rollout_loss_configuration
from glassbox.core.synthetic import true_parameters

ROOT=Path(sys.argv[1])
design=json.loads((ROOT/'design.json').read_text())
methods=design['methods']
assert all(len(list((ROOT/c).glob('*/report.json')))==len(design['replicates']) for c in design['conditions'])

@jax.jit
def predictions(params, initial, histories, controls):
    def one(state, history, control):
        latent=control_state_after_history(params,history,.02)
        return rollout_with_latent(params,state,control,.02,latent)[0]
    return jax.vmap(one)(initial,histories,controls)


def utilization(states,envelope):
    rotations=quaternion_to_rotation_matrices(states[...,6:10])
    velocity=np.einsum('...ji,...j->...i',rotations,states[...,3:6])
    ratios=np.concatenate((abs(velocity-envelope.body_velocity_center_m_s)/envelope.body_velocity_half_width_m_s,
        abs(states[...,10:13]-envelope.angular_velocity_center_rad_s)/envelope.angular_velocity_half_width_rad_s),axis=-1)
    return np.stack([np.max(ratios[:,:n+1],axis=(1,2)) for n in (5,25,50)],axis=1)


def ratio(a,b):
    a,b=np.asarray(a),np.asarray(b)
    return np.divide(a,b,out=np.full_like(a,np.nan),where=b>0)


def serial(value):
    if isinstance(value,dict): return {k:serial(v) for k,v in value.items()}
    if isinstance(value,np.ndarray): return serial(value.tolist())
    if isinstance(value,(list,tuple)): return [serial(v) for v in value]
    if isinstance(value,(float,np.floating)) and not np.isfinite(value): return None
    if isinstance(value,np.generic): return value.item()
    return value


x,noise0,noise1=np.asarray(list(itertools.product((-1.,1.),(-2.,2.),(-2.,2.)))).T
gain=.8
initial=x+noise0
future=gain*x+noise1
observed_gain=float(initial@future/(initial@initial))
true_gain=float(x@future/(x@x))
np.testing.assert_allclose([observed_gain,true_gain],[.16,.8],atol=1e-15)
control={'true_gain':gain,'optimal_gain_from_noisy_start':observed_gain,
    'optimal_gain_from_true_start':true_gain,
    'noisy_start_mse_at_true_gain':float(np.mean((future-gain*initial)**2)),
    'noisy_start_mse_at_fitted_gain':float(np.mean((future-observed_gain*initial)**2))}
report={'design':design,'finite_scalar_control':control,'conditions':{}}
for condition in design['conditions']:
    clean_tests=[study.truth_flight(500000+i,condition=='collective') for i in range(3)]
    true_test=trajectory_windows(clean_tests,horizon=50)
    per_fit=[]
    for replicate in design['replicates']:
        destination=ROOT/condition/f'{replicate:02d}'
        with np.load(destination/'arrays.npz',allow_pickle=False) as source:
            arrays=dict(source)
        clean=[study.truth_flight(100000+10*replicate+i,condition=='collective') for i in range(2)]
        train=[study.noisy_trajectory(t,200000+10*replicate+i,study.CONDITIONS[condition],'train') for i,t in enumerate(clean)]
        envelope=rollout_loss_configuration([trajectory_windows(train,horizon=25)]).validity_envelope
        observed_test=trajectory_windows([study.noisy_trajectory(t,600000+10*replicate+i,
            study.CONDITIONS[condition],'test') for i,t in enumerate(clean_tests)],horizon=50)
        supports={'truth':utilization(true_test.target_states,envelope)}
        for name in methods:
            params=with_structured_parameter_vector(true_parameters(),jnp.asarray(arrays[f'{name}/theta']))
            for mode,w in [('observed',observed_test),('physical',true_test)]:
                states=np.asarray(predictions(params,w.initial_states,w.control_histories,w.controls))
                supports[f'{name}/{mode}']=utilization(states,envelope)
        inside=np.max(np.stack(list(supports.values())),axis=0)<=1
        assert np.all(inside.sum(axis=0)>0)
        np.savez_compressed(destination/'support.npz',inside=inside,**supports)
        row={'inside_support_fraction':inside.mean(axis=0), 'methods':{}}
        for name in methods:
            error=arrays[f'{name}/theta']-np.asarray(design['true_parameters'])
            values={'parameter_mse':np.mean(error[design['estimable_indices']]**2)}
            for mode in ('observed','latent','physical'):
                e=arrays[f'{name}/{mode}_error']
                group=np.stack([np.mean(e[...,indices]**2,axis=-1)
                    for indices in study.TANGENT_GROUP_INDICES.values()],axis=1)
                values[f'{mode}_mse']=group.mean(axis=0)
                values[f'inside_support_{mode}_mse']=(group*inside[:,None,:]).sum(axis=0)/inside.sum(axis=0)
                saved=json.loads((destination/'report.json').read_text())[name][f'{mode}_mse']
                np.testing.assert_allclose(values[f'{mode}_mse'],saved,rtol=1e-6,atol=1e-20)
            row['methods'][name]=values
        per_fit.append(row)
    summary={'inside_support_fraction':np.mean([r['inside_support_fraction'] for r in per_fit],axis=0),
             'methods':{},'comparisons':{},'per_fit':per_fit}
    for name in methods:
        summary['methods'][name]={key:np.mean([r['methods'][name][key] for r in per_fit],axis=0)
            for key in per_fit[0]['methods'][name]}
    for new,old in [('joint_400','fixed_400'),('joint_4000','fixed_4000'),('oracle_4000','fixed_4000')]:
        summary['comparisons'][f'{new}_over_{old}']={key:ratio(value,summary['methods'][old][key])
            for key,value in summary['methods'][new].items()}
    report['conditions'][condition]=summary
    print(condition,'support',summary['inside_support_fraction'],flush=True)
    for comparison in summary['comparisons']:
        r=summary['comparisons'][comparison]
        print(comparison,'parameter MSE',r['parameter_mse'],'observed MSE at 1s',r['inside_support_observed_mse'][:,-1],
              'physical MSE at 1s',r['inside_support_physical_mse'][:,-1],flush=True)
(ROOT/'report.json').write_text(json.dumps(serial(report),indent=2,allow_nan=False)+'\n')
