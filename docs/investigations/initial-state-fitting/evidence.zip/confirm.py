"""Compare fixed, fitted and known rollout starts on fresh noisy training flights."""
import hashlib
import json
import sys
import time
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np

sys.path.insert(0, str(Path.cwd() / 'scripts'))
import evaluate_fit_uncertainty as study
from glassbox.core.data import trajectory_windows
from glassbox.core.dynamics import (control_state_after_history, rollout_with_latent,
    structured_parameter_vector, zero_angular_cross_coupling_gradient,
    zero_thrust_command_offset_gradient)
from glassbox.core.geometry import rigid_body_local_error, state_plus_tangent
from glassbox.core.identification import batch_rollout_loss, fit_dynamics, rollout_loss_configuration
from glassbox.core.synthetic import initial_parameter_guess, true_parameters
from dataclasses import replace

ROOT = Path('/tmp/glassbox-noisy-fit-investigation/confirmation')
ROOT.mkdir()
TRUTH = np.asarray(structured_parameter_vector(true_parameters()))
REPLICATES = tuple(range(16, 20))


def joint_fit(w, configuration):
    arrays = tuple(jnp.asarray(a) for a in
                   (w.initial_states, w.control_histories, w.controls, w.target_states))
    scale = jnp.asarray(np.concatenate((configuration.position_scale_m,
        configuration.velocity_scale_m_s, np.repeat(configuration.attitude_scale_rad, 3),
        configuration.angular_velocity_scale_rad_s)))
    def fixed_loss(params, initial):
        return batch_rollout_loss(params, initial, *arrays[1:], w.dt_s, configuration,
                                  control_roles=w.control_roles)
    normalizer = fixed_loss(initial_parameter_guess(), arrays[0])
    def objective(variables):
        params, offsets = variables
        initial = jax.vmap(state_plus_tangent)(arrays[0], offsets * scale)
        initial_error = .25 * jnp.mean(jnp.mean(offsets[:, :3]**2, axis=1)
            + jnp.mean(offsets[:, 3:6]**2, axis=1) + jnp.sum(offsets[:, 6:9]**2, axis=1)
            + jnp.mean(offsets[:, 9:]**2, axis=1))
        return (fixed_loss(params, initial) + initial_error / (w.controls.shape[1] * 2)) / normalizer
    value_and_grad = jax.value_and_grad(objective)
    @jax.jit
    def step(variables, first, second, index):
        value, (parameter_gradient, offsets_gradient) = value_and_grad(variables)
        parameter_gradient = zero_angular_cross_coupling_gradient(
            zero_thrust_command_offset_gradient(parameter_gradient))
        gradient = parameter_gradient, offsets_gradient
        norm = jnp.sqrt(sum(jnp.sum(a*a) for a in jax.tree.leaves(gradient)))
        gradient = jax.tree.map(lambda a: a*jnp.minimum(1., 10./(norm+1e-12)), gradient)
        first = jax.tree.map(lambda a,g: .9*a+.1*g, first, gradient)
        second = jax.tree.map(lambda a,g: .999*a+.001*g*g, second, gradient)
        variables = jax.tree.map(lambda p,a,b: p-.02*(a/(1-.9**index)) /
            (jnp.sqrt(b/(1-.999**index))+1e-8), variables, first, second)
        return variables, first, second, value
    variables = initial_parameter_guess(), jnp.zeros((len(w.initial_states), 12))
    first = jax.tree.map(jnp.zeros_like, variables)
    second = first
    results = {}
    for index in range(1, 4001):
        variables, first, second, value = step(variables, first, second, index)
        if index in (400, 4000):
            results[f'joint_{index}'] = variables[0]
            assert np.isfinite(float(value))
    return results


@jax.jit
def test_errors(params, initial, histories, controls, observed, truth):
    def predict(state, history, control, measured, actual):
        latent = control_state_after_history(params, history, .02)
        states, _ = rollout_with_latent(params, state, control, .02, latent)
        indices = jnp.asarray((5,25,50))
        return (jax.vmap(rigid_body_local_error)(states, measured)[indices],
                jax.vmap(rigid_body_local_error)(states, actual)[indices])
    return jax.vmap(predict)(initial, histories, controls, observed, truth)


def group_mse(errors):
    return np.stack([np.mean(errors[..., indices]**2, axis=(0, 2))
                     for indices in study.TANGENT_GROUP_INDICES.values()])


source_paths = [Path(__file__), Path('scripts/evaluate_fit_uncertainty.py'),
                *sorted(Path('src/glassbox').rglob('*.py'))]
design = dict(replicates=REPLICATES, conditions=study.CONDITIONS,
    measurement_noise_std=study.NOISE_STD.tolist(), sample_period_s=.02,
    training='two independent six-second flights; training seed 100000+10*replicate+i',
    observation_noise_seed='200000+10*replicate+i',
    test='three shared six-second test command designs, seeds 500000+i',
    test_observation_noise_seed='600000+10*replicate+i',
    horizons_s=study.HORIZONS, training_horizon_steps=25, learning_rate=.02,
    methods=['fixed_400','joint_400','fixed_4000','joint_4000','oracle_4000'],
    initial_state_policy='joint: 12 scaled tangent offsets per window, initial observation weighted like one forecast sample',
    oracle='true window initial states; noisy future targets unchanged; diagnostic only',
    groups=list(study.TANGENT_GROUP_INDICES), true_parameters=TRUTH.tolist(),
    parameter_names=study.structured_parameter_names(true_parameters()),
    estimable_indices=[0,2,3,4,5,6,7,8,9],
    independent_unit='fit replicate; conditions and test designs paired',
    jax_version=jax.__version__, x64=bool(jax.config.jax_enable_x64),
    source_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths})
(ROOT/'design.json').write_text(json.dumps(design,indent=2)+'\n')
for condition in study.CONDITIONS:
    tests=[study.truth_flight(500000+i, condition=='collective') for i in range(3)]
    true_test=trajectory_windows(tests,horizon=50)
    for replicate in REPLICATES:
        start=time.monotonic()
        clean=[study.truth_flight(100000+10*replicate+i, condition=='collective') for i in range(2)]
        measured=[study.noisy_trajectory(t,200000+10*replicate+i,study.CONDITIONS[condition],'train') for i,t in enumerate(clean)]
        w=trajectory_windows(measured,horizon=25)
        true_w=trajectory_windows(clean,horizon=25)
        configuration=rollout_loss_configuration([w])
        models=joint_fit(w,configuration)
        for steps in (400,4000):
            result=fit_dynamics([w],initial_parameter_guess(),steps=steps,learning_rate=.02,
                               diagonal_angular_control=True,loss_configuration=configuration)
            assert not result.diverged
            models[f'fixed_{steps}']=result.params
        result=fit_dynamics([replace(w,initial_states=true_w.initial_states)],
            initial_parameter_guess(),steps=4000,learning_rate=.02,
            diagonal_angular_control=True,loss_configuration=configuration)
        assert not result.diverged
        models['oracle_4000']=result.params
        observed_test=trajectory_windows([study.noisy_trajectory(t,600000+10*replicate+i,
            study.CONDITIONS[condition],'test') for i,t in enumerate(tests)],horizon=50)
        rows={}
        arrays={}
        for name,p in models.items():
            observed_error,latent_error=test_errors(p,observed_test.initial_states,
                observed_test.control_histories,observed_test.controls,
                observed_test.target_states,true_test.target_states)
            _,physical_error=test_errors(p,true_test.initial_states,
                true_test.control_histories,true_test.controls,
                observed_test.target_states,true_test.target_states)
            theta=np.asarray(structured_parameter_vector(p))
            arrays.update({f'{name}/theta': theta, f'{name}/observed_error':np.asarray(observed_error),
                f'{name}/latent_error':np.asarray(latent_error),f'{name}/physical_error':np.asarray(physical_error)})
            rows[name]={'parameter_error':(theta-TRUTH).tolist(),
                'observed_mse':group_mse(np.asarray(observed_error)).tolist(),
                'latent_mse':group_mse(np.asarray(latent_error)).tolist(),
                'physical_mse':group_mse(np.asarray(physical_error)).tolist()}
        destination=ROOT/condition/f'{replicate:02d}'
        destination.mkdir(parents=True)
        np.savez_compressed(destination/'arrays.npz',**arrays)
        (destination/'report.json').write_text(json.dumps(rows,indent=2,allow_nan=False)+'\n')
        print(condition,replicate,'seconds',round(time.monotonic()-start,1),flush=True)
        jax.clear_caches()
